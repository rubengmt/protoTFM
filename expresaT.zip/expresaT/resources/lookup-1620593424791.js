(function(window, undefined) {
  var dictionary = {
    "0b97593d-f01f-4a1e-89fb-51da0aa8218c": "2_3_3 ENTONACION",
    "70bdc02c-e3ad-4423-a37a-06604ab5af05": "2_3_4 Aprende LNV_5",
    "c3bb3782-c874-4c74-9224-0044a28bea6b": "2_3_4 Aprende LNV_3",
    "d0bf3351-f093-4d15-a06a-518fc9c494cc": "2_4_2 FORO",
    "48451722-5b09-4030-9ae5-2226ee5c07a1": "2_2_1 _1 Historia Palabras",
    "a62c0753-adb7-4729-bc59-41e765ddd2ea": "FF2 Fin VIsualización",
    "26608276-b1b9-4700-8ce1-303f1ce93007": "2_2_1 CUENTA HISTORIAS",
    "61b9ee47-27a3-44a6-9848-5ed93a82a2b1": "2_3 APRENDE",
    "d77fdfb2-5141-4832-8307-3aa547f4bb02": "2_4 AULA",
    "67eb51ea-05a7-4d06-aea3-131f40791214": "2_4_4 Exposicion Aula",
    "f18d0fae-f0f6-4e32-b20c-2b7d00640f83": "FF4_2 Evaliación Compañeros",
    "75e6072e-7ed4-422a-baf2-e8a4636dd54f": "2_4_1 Debate",
    "2324639a-8670-4d26-bf4c-a533e885485d": "2_3_2 MULETILLAS",
    "4ad591f3-0008-4180-8030-c0588b16b5f1": "FF2_Fin VIsualizaciónSinEv_nOTuSE",
    "c963c7db-b29e-4696-b850-9e3aaea216c1": "1_0_bis_Profe_Valida",
    "9fd47688-8855-43cb-a0f7-10777a36c125": "FF3 Exposicion G",
    "ad733296-6224-4884-b94d-dcbb9d26cff8": "2_3_4 Aprende LNV_7",
    "8a85d61a-6753-4d6d-a6f5-9f9ffb52666d": "FFF PANTALLA SALIDA",
    "ed59bb14-78ec-49f7-9951-f537ff581ca4": "FF1b Reproduce_Expo",
    "3b911434-f219-47e3-91f2-93612b9d4a8a": "FF4_1 Evaluación profesor",
    "1ec06ea1-5fe6-47f2-86df-411be0efa241": "2_4_3_1 Escuchar Podcast",
    "8ccbb7e6-00fc-4874-9375-a991991a343d": "2_2_1 _2 Historia Imagenes",
    "a89eb890-f116-4302-8a9b-a6067c7a14b7": "2_4_3_2 Crear PODCAST",
    "62cecbf0-7e84-4308-b8f7-5bf049fe3273": "FF1c Reproduce_Sonido",
    "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b": "FF3 Buena Entoncacion",
    "f5130a98-d53a-49ea-a238-10929f5f1195": "FF4 EVALUACION",
    "5dfb0b9c-a1d5-46f5-83ff-c651935afa01": "2_2_4_1 PON_GESTOS",
    "e06d8014-6145-4b23-a5fe-c8b7f4004025": "2_3_4 Aprende LNV_0",
    "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d": "2_4_3 PODCASTS",
    "a844354a-2aab-49b8-892f-984837ef1518": "FF1 Visualiza_Video",
    "afea0b78-ce1c-4b33-9c62-d3408d7fc829": "2_2_2 DISCURSO_PRACT",
    "a6172d59-27a9-4588-ab77-7e63dc105639": "FFF8 Fin Debate",
    "05bcb274-adda-4220-827d-659d690099a5": "2_3_4 Aprende LNV_6",
    "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a": "2_3_4 Aprende LNV_4",
    "47b84409-242f-4e09-942c-caf0ab5ce5dc": "1_2_1 Menu_Profesor",
    "44c5a5ee-2a9b-4f6a-bb67-462ac651fa95": "2_2_4 PRACTICA_LNV_NotUse",
    "c78d41b0-d2d2-4733-bfd7-bbdd563e7685": "FF4_3 Evaliación Aula",
    "ec9820f2-1a38-4f24-90a9-6f619de1e4d5": "2_2 PRACTICA",
    "a17f4ddd-841f-483b-bc3f-880cab6dc4bc": "FF9_FinForo",
    "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d": "2_3_4 Aprende LNV_2",
    "96d8da02-d9c0-4acd-a61f-465f76c11edd": "2_3_4 Aprende LNV_8",
    "bd022cbb-530d-4cb6-b026-12fd8af7cf91": "2_2_3 Exposicion",
    "fc5a2ddd-8b90-4f7e-a804-1338c55c261e": "2_3_4 Aprende LNV_10",
    "37a542a2-f31f-4d33-ad60-39863022745b": "2_3_4 Aprende LNV_9",
    "9c8a816b-cea5-4a91-8f7c-a5fe709e83fe": "0 ENTRADA",
    "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec": "1_0_Alumno_Valida",
    "ae14161c-89d7-45e2-ba6b-2d4197a8106c": "FF10_FinPodcast",
    "5616f381-55b8-49cc-bec1-ea3bea0704c8": "2_3_1 LECCIONES",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "1_1 Menu_Alumno",
    "bd231881-3a5f-4568-ba87-9e5db0b6f012": "2_3_4 Aprende LNV_1",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);