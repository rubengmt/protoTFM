(function(window, undefined) {

  var jimLinks = {
    "0b97593d-f01f-4a1e-89fb-51da0aa8218c" : {
      "Image_3" : [
        "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"
      ]
    },
    "70bdc02c-e3ad-4423-a37a-06604ab5af05" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "05bcb274-adda-4220-827d-659d690099a5"
      ]
    },
    "c3bb3782-c874-4c74-9224-0044a28bea6b" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"
      ]
    },
    "d0bf3351-f093-4d15-a06a-518fc9c494cc" : {
      "Image_2" : [
        "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"
      ],
      "Image_141" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_142" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_143" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_144" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_145" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Button-black" : [
        "d77fdfb2-5141-4832-8307-3aa547f4bb02"
      ]
    },
    "48451722-5b09-4030-9ae5-2226ee5c07a1" : {
      "Button-black" : [
        "26608276-b1b9-4700-8ce1-303f1ce93007"
      ]
    },
    "a62c0753-adb7-4729-bc59-41e765ddd2ea" : {
      "Button-black_1" : [
        "ed59bb14-78ec-49f7-9951-f537ff581ca4"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_2" : [
        "f5130a98-d53a-49ea-a238-10929f5f1195"
      ]
    },
    "26608276-b1b9-4700-8ce1-303f1ce93007" : {
      "Button" : [
        "48451722-5b09-4030-9ae5-2226ee5c07a1"
      ],
      "Button_1" : [
        "8ccbb7e6-00fc-4874-9375-a991991a343d"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "61b9ee47-27a3-44a6-9848-5ed93a82a2b1" : {
      "Ellipse_11" : [
        "2324639a-8670-4d26-bf4c-a533e885485d"
      ],
      "Ellipse_12" : [
        "5616f381-55b8-49cc-bec1-ea3bea0704c8"
      ],
      "Ellipse_13" : [
        "e06d8014-6145-4b23-a5fe-c8b7f4004025"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Ellipse_14" : [
        "0b97593d-f01f-4a1e-89fb-51da0aa8218c"
      ]
    },
    "d77fdfb2-5141-4832-8307-3aa547f4bb02" : {
      "Ellipse_2" : [
        "75e6072e-7ed4-422a-baf2-e8a4636dd54f"
      ],
      "Ellipse_6" : [
        "d0bf3351-f093-4d15-a06a-518fc9c494cc"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "8a85d61a-6753-4d6d-a6f5-9f9ffb52666d"
      ],
      "Ellipse_3" : [
        "67eb51ea-05a7-4d06-aea3-131f40791214"
      ]
    },
    "67eb51ea-05a7-4d06-aea3-131f40791214" : {
      "Button-black" : [
        "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"
      ],
      "Image_137" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_138" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_139" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_140" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_141" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_142" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_143" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ],
      "Image_144" : [
        "9fd47688-8855-43cb-a0f7-10777a36c125"
      ]
    },
    "f18d0fae-f0f6-4e32-b20c-2b7d00640f83" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "75e6072e-7ed4-422a-baf2-e8a4636dd54f" : {
      "Button-black" : [
        "d77fdfb2-5141-4832-8307-3aa547f4bb02"
      ],
      "Image_9" : [
        "a6172d59-27a9-4588-ab77-7e63dc105639"
      ]
    },
    "2324639a-8670-4d26-bf4c-a533e885485d" : {
      "Button-black" : [
        "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"
      ]
    },
    "4ad591f3-0008-4180-8030-c0588b16b5f1" : {
      "Button-black_1" : [
        "ed59bb14-78ec-49f7-9951-f537ff581ca4"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "c963c7db-b29e-4696-b850-9e3aaea216c1" : {
      "Ellipse_9" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Ellipse_10" : [
        "9c8a816b-cea5-4a91-8f7c-a5fe709e83fe"
      ]
    },
    "9fd47688-8855-43cb-a0f7-10777a36c125" : {
      "Image_2" : [
        "a62c0753-adb7-4729-bc59-41e765ddd2ea"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "ad733296-6224-4884-b94d-dcbb9d26cff8" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "96d8da02-d9c0-4acd-a61f-465f76c11edd"
      ]
    },
    "ed59bb14-78ec-49f7-9951-f537ff581ca4" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "3b911434-f219-47e3-91f2-93612b9d4a8a" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "1ec06ea1-5fe6-47f2-86df-411be0efa241" : {
      "Button-black" : [
        "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"
      ],
      "Image_137" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_138" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_139" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_140" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_141" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_142" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_143" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ],
      "Image_144" : [
        "62cecbf0-7e84-4308-b8f7-5bf049fe3273"
      ]
    },
    "8ccbb7e6-00fc-4874-9375-a991991a343d" : {
      "Button-black" : [
        "26608276-b1b9-4700-8ce1-303f1ce93007"
      ]
    },
    "a89eb890-f116-4302-8a9b-a6067c7a14b7" : {
      "Image_2" : [
        "ae14161c-89d7-45e2-ba6b-2d4197a8106c"
      ],
      "Button-black" : [
        "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"
      ]
    },
    "62cecbf0-7e84-4308-b8f7-5bf049fe3273" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "1ec06ea1-5fe6-47f2-86df-411be0efa241"
      ]
    },
    "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b" : {
      "Button-black_1" : [
        "ed59bb14-78ec-49f7-9951-f537ff581ca4"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "f5130a98-d53a-49ea-a238-10929f5f1195" : {
      "Button" : [
        "3b911434-f219-47e3-91f2-93612b9d4a8a"
      ],
      "Button_1" : [
        "f18d0fae-f0f6-4e32-b20c-2b7d00640f83"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "c78d41b0-d2d2-4733-bfd7-bbdd563e7685"
      ]
    },
    "5dfb0b9c-a1d5-46f5-83ff-c651935afa01" : {
      "Image_2" : [
        "a62c0753-adb7-4729-bc59-41e765ddd2ea"
      ],
      "Button-black" : [
        "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"
      ]
    },
    "e06d8014-6145-4b23-a5fe-c8b7f4004025" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "bd231881-3a5f-4568-ba87-9e5db0b6f012"
      ]
    },
    "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d" : {
      "Button" : [
        "1ec06ea1-5fe6-47f2-86df-411be0efa241"
      ],
      "Button_1" : [
        "a89eb890-f116-4302-8a9b-a6067c7a14b7"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "afea0b78-ce1c-4b33-9c62-d3408d7fc829" : {
      "Image_2" : [
        "a62c0753-adb7-4729-bc59-41e765ddd2ea"
      ],
      "Button-black" : [
        "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"
      ]
    },
    "a6172d59-27a9-4588-ab77-7e63dc105639" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "05bcb274-adda-4220-827d-659d690099a5" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "ad733296-6224-4884-b94d-dcbb9d26cff8"
      ]
    },
    "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "70bdc02c-e3ad-4423-a37a-06604ab5af05"
      ]
    },
    "47b84409-242f-4e09-942c-caf0ab5ce5dc" : {
      "Ellipse_1" : [
        "d77fdfb2-5141-4832-8307-3aa547f4bb02"
      ],
      "Ellipse_4" : [
        "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"
      ]
    },
    "44c5a5ee-2a9b-4f6a-bb67-462ac651fa95" : {
      "Ellipse_11" : [
        "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"
      ],
      "Ellipse_4" : [
        "bd022cbb-530d-4cb6-b026-12fd8af7cf91"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "c78d41b0-d2d2-4733-bfd7-bbdd563e7685" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "ec9820f2-1a38-4f24-90a9-6f619de1e4d5" : {
      "Ellipse_3" : [
        "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"
      ],
      "Ellipse_10" : [
        "26608276-b1b9-4700-8ce1-303f1ce93007"
      ],
      "Ellipse_11" : [
        "afea0b78-ce1c-4b33-9c62-d3408d7fc829"
      ],
      "Ellipse_4" : [
        "bd022cbb-530d-4cb6-b026-12fd8af7cf91"
      ],
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "a17f4ddd-841f-483b-bc3f-880cab6dc4bc" : {
      "Button-black" : [
        "d0bf3351-f093-4d15-a06a-518fc9c494cc"
      ]
    },
    "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "c3bb3782-c874-4c74-9224-0044a28bea6b"
      ]
    },
    "96d8da02-d9c0-4acd-a61f-465f76c11edd" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "37a542a2-f31f-4d33-ad60-39863022745b"
      ]
    },
    "bd022cbb-530d-4cb6-b026-12fd8af7cf91" : {
      "Image_2" : [
        "a62c0753-adb7-4729-bc59-41e765ddd2ea"
      ],
      "Button-black" : [
        "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"
      ]
    },
    "fc5a2ddd-8b90-4f7e-a804-1338c55c261e" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "37a542a2-f31f-4d33-ad60-39863022745b" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"
      ]
    },
    "9c8a816b-cea5-4a91-8f7c-a5fe709e83fe" : {
      "Ellipse_9" : [
        "8a85d61a-6753-4d6d-a6f5-9f9ffb52666d"
      ],
      "Ellipse_10" : [
        "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec"
      ]
    },
    "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec" : {
      "Ellipse_9" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Ellipse_10" : [
        "9c8a816b-cea5-4a91-8f7c-a5fe709e83fe"
      ]
    },
    "ae14161c-89d7-45e2-ba6b-2d4197a8106c" : {
      "Button-black" : [
        "a89eb890-f116-4302-8a9b-a6067c7a14b7"
      ]
    },
    "5616f381-55b8-49cc-bec1-ea3bea0704c8" : {
      "Image_1" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_2" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_3" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_4" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_5" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_6" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_7" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Image_8" : [
        "a844354a-2aab-49b8-892f-984837ef1518"
      ],
      "Button-black" : [
        "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Ellipse_1" : [
        "d77fdfb2-5141-4832-8307-3aa547f4bb02"
      ],
      "Ellipse_4" : [
        "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"
      ],
      "Ellipse_9" : [
        "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"
      ],
      "Button-black_1" : [
        "8a85d61a-6753-4d6d-a6f5-9f9ffb52666d"
      ]
    },
    "bd231881-3a5f-4568-ba87-9e5db0b6f012" : {
      "Button-black" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button-black_1" : [
        "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);