jQuery("#simulation")
  .on("click", ".s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Ellipse_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/5dfb0b9c-a1d5-46f5-83ff-c651935afa01"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Ellipse_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/26608276-b1b9-4700-8ce1-303f1ce93007"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Ellipse_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/afea0b78-ce1c-4b33-9c62-d3408d7fc829"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Ellipse_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bd022cbb-530d-4cb6-b026-12fd8af7cf91"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-black")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5 #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });