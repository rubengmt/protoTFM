jQuery("#simulation")
  .on("click", ".s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button-black")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-black_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1 span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1 span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-9a249b3e-9cda-45f8-8ea8-22b12d3c121b #s-Button-black_1 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d0bf3351-f093-4d15-a06a-518fc9c494cc"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });