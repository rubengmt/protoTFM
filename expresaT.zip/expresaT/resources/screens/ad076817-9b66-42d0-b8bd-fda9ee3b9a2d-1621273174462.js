jQuery("#simulation")
  .on("click", ".s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Paragraph_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_39" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_40" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Image_41" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Paragraph_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Ok-green" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-black")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-black_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1 span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1 > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1 span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-ad076817-9b66-42d0-b8bd-fda9ee3b9a2d #s-Button-black_1 > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/c3bb3782-c874-4c74-9224-0044a28bea6b"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });