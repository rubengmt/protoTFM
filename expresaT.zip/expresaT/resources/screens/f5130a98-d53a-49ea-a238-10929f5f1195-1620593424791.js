jQuery("#simulation")
  .on("click", ".s-f5130a98-d53a-49ea-a238-10929f5f1195 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button span": {
                      "attributes": {
                        "color": "#80B8F1"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button span": {
                      "attributes": {
                        "color": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3b911434-f219-47e3-91f2-93612b9d4a8a"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_1": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_1 span": {
                      "attributes": {
                        "color": "#80B8F1"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_1": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_1 span": {
                      "attributes": {
                        "color": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/f18d0fae-f0f6-4e32-b20c-2b7d00640f83"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button-black")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_2 span": {
                      "attributes": {
                        "color": "#80B8F1"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_2": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-f5130a98-d53a-49ea-a238-10929f5f1195 #s-Button_2 span": {
                      "attributes": {
                        "color": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/c78d41b0-d2d2-4733-bfd7-bbdd563e7685"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });