jQuery("#simulation")
  .on("click", ".s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(jimUtil.isAlternateModeActive()) return;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button-black")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  },{
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black span": {
                      "attributes": {
                        "color": "#999999"
                      }
                    }
                  },{
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#999999",
                        "border-right-color": "#999999",
                        "border-bottom-color": "#999999",
                        "border-left-color": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black": {
                      "attributes": {
                        "font-size": "0pt"
                      }
                    }
                  },{
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black > .borderLayer": {
                      "attributes": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  },{
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black span": {
                      "attributes": {
                        "color": "#434343"
                      }
                    }
                  },{
                    "#s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc #s-Button-black > .borderLayer": {
                      "attributes-ie": {
                        "border-top-color": "#404040",
                        "border-right-color": "#404040",
                        "border-bottom-color": "#404040",
                        "border-left-color": "#404040"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d0bf3351-f093-4d15-a06a-518fc9c494cc"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-checkbox_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-checkbox_2" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Rectangle_3" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Rectangle_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Rectangle_3" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-checkbox_2" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });