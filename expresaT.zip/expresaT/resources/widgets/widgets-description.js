	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Paragraph_1", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_4", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Play", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_1", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Stop", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_9", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Pause", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_22", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Paragraph_2", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_5", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Radio Button Off", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_3", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Radio Button On", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_11", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "0b97593d-f01f-4a1e-89fb-51da0aa8218c"]] = ["Reset", "s-Image_11"]; 

	widgets.descriptionMap[["s-Paragraph_1", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "70bdc02c-e3ad-4423-a37a-06604ab5af05"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "c3bb3782-c874-4c74-9224-0044a28bea6b"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Image_4", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Image_39", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Add green transparent button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Input-text_4", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Input-text_4", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Input multipleline text", "s-Input-text_4"]; 

	widgets.descriptionMap[["s-Input_4", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Input Text Field", "s-Input_4"]; 

	widgets.descriptionMap[["s-Image_40", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Close blue button", "s-Image_40"]; 

	widgets.descriptionMap[["s-c79d351d", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-c79d351d", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_13", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_13", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-50b8262b", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-50b8262b", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_14", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_14", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-48ba33dc", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-48ba33dc", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_15", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_15", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-aeb96b00", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-aeb96b00", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_16", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_16", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-45359874", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-45359874", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_17", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_17", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-cbf6d7c8", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-cbf6d7c8", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_18", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_18", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-8cd6c902", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-8cd6c902", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_19", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_19", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-dc73b821", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-dc73b821", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_20", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_20", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-53ef084e", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-53ef084e", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_21", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_21", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-e4c991b6", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-e4c991b6", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_22", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_22", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-544d0d62", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-544d0d62", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_23", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_23", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-38f26f59", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-38f26f59", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_24", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_24", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Image_41", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Close blue button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_141", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_141", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Play Circle", "s-Image_141"]; 

	widgets.descriptionMap[["s-Image_142", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_142", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Play Circle", "s-Image_142"]; 

	widgets.descriptionMap[["s-Image_143", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_143", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Play Circle", "s-Image_143"]; 

	widgets.descriptionMap[["s-Image_144", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_144", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Play Circle", "s-Image_144"]; 

	widgets.descriptionMap[["s-Image_145", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_145", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Play Circle", "s-Image_145"]; 

	widgets.descriptionMap[["s-Category_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Button-black", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Image_31", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_31", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Show", "s-Image_31"]; 

	widgets.descriptionMap[["s-Image_12", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["File", "s-Image_12"]; 

	widgets.descriptionMap[["s-Bg", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_1", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Item_1", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Item_2", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_3", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ""; 

			widgets.rootWidgetMap[["s-Item_3", "d0bf3351-f093-4d15-a06a-518fc9c494cc"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_1", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_4", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_3", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Input_1", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Check Box", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_4", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "48451722-5b09-4030-9ae5-2226ee5c07a1"]] = ["Paragraph", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_3", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button-black_1", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Button-black", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_2", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_2", "a62c0753-adb7-4729-bc59-41e765ddd2ea"]] = ["Small button black", "s-Button-black_2"]; 

	widgets.descriptionMap[["s-Button", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ["Large button", "s-Button"]; 

	widgets.descriptionMap[["s-Button_1", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ["Large button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "26608276-b1b9-4700-8ce1-303f1ce93007"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_9", "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Button-black", "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "61b9ee47-27a3-44a6-9848-5ed93a82a2b1"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black", "d77fdfb2-5141-4832-8307-3aa547f4bb02"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "d77fdfb2-5141-4832-8307-3aa547f4bb02"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "d77fdfb2-5141-4832-8307-3aa547f4bb02"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "d77fdfb2-5141-4832-8307-3aa547f4bb02"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_9", "d77fdfb2-5141-4832-8307-3aa547f4bb02"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "d77fdfb2-5141-4832-8307-3aa547f4bb02"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_1", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Button-black", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Image_137", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_137", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_137"]; 

	widgets.descriptionMap[["s-Image_138", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_138", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_138"]; 

	widgets.descriptionMap[["s-Image_139", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_139", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_139"]; 

	widgets.descriptionMap[["s-Image_140", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_140"]; 

	widgets.descriptionMap[["s-Image_141", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_141", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_141"]; 

	widgets.descriptionMap[["s-Image_142", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_142", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_142"]; 

	widgets.descriptionMap[["s-Image_143", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_143", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_143"]; 

	widgets.descriptionMap[["s-Image_144", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ""; 

			widgets.rootWidgetMap[["s-Image_144", "67eb51ea-05a7-4d06-aea3-131f40791214"]] = ["Play Circle", "s-Image_144"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f18d0fae-f0f6-4e32-b20c-2b7d00640f83"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f18d0fae-f0f6-4e32-b20c-2b7d00640f83"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "f18d0fae-f0f6-4e32-b20c-2b7d00640f83"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "f18d0fae-f0f6-4e32-b20c-2b7d00640f83"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_22", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Image_8", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Radio Button Off", "s-Image_8"]; 

	widgets.descriptionMap[["s-Image_9", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_9", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Radio Button On", "s-Image_9"]; 

	widgets.descriptionMap[["s-Image_10", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_10", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Facecall filled", "s-Image_10"]; 

	widgets.descriptionMap[["s-Image_11", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_11", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Facecall filled", "s-Image_11"]; 

	widgets.descriptionMap[["s-Image_24", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_24", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Mic filled", "s-Image_24"]; 

	widgets.descriptionMap[["s-Image_25", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_25", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Mute Mic", "s-Image_25"]; 

	widgets.descriptionMap[["s-Image_7", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_7", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Flash filled", "s-Image_7"]; 

	widgets.descriptionMap[["s-Image_12", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Flash filled", "s-Image_12"]; 

	widgets.descriptionMap[["s-Image_15", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_15", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Forward Arrow", "s-Image_15"]; 

	widgets.descriptionMap[["s-Image_16", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "75e6072e-7ed4-422a-baf2-e8a4636dd54f"]] = ["Reverse Arrow", "s-Image_16"]; 

	widgets.descriptionMap[["s-Image_4", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Category_2", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Image_39", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Add green transparent button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Input-text_4", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Input-text_4", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Input multipleline text", "s-Input-text_4"]; 

	widgets.descriptionMap[["s-Image_40", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Close blue button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Input_4", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Input Text Field", "s-Input_4"]; 

	widgets.descriptionMap[["s-a5de125a", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-a5de125a", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_13", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_13", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-cf878f07", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-cf878f07", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_14", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_14", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-c530ddc5", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-c530ddc5", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_15", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_15", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-42e48799", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-42e48799", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_16", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_16", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-e2c14aca", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-e2c14aca", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_17", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_17", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-6a489396", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-6a489396", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_18", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_18", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-18cc2cd5", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-18cc2cd5", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_19", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_19", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-4e4adc80", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-4e4adc80", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_20", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_20", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-28c83082", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-28c83082", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_21", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_21", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-dfe566f0", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-dfe566f0", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_22", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_22", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-2af5101a", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-2af5101a", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_23", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_23", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-a11f86e0", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-a11f86e0", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_24", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_24", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Image_41", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Close blue button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Paragraph_1", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "2324639a-8670-4d26-bf4c-a533e885485d"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_3", "4ad591f3-0008-4180-8030-c0588b16b5f1"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "4ad591f3-0008-4180-8030-c0588b16b5f1"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button-black_1", "4ad591f3-0008-4180-8030-c0588b16b5f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "4ad591f3-0008-4180-8030-c0588b16b5f1"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Button-black", "4ad591f3-0008-4180-8030-c0588b16b5f1"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "4ad591f3-0008-4180-8030-c0588b16b5f1"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Input_1", "c963c7db-b29e-4696-b850-9e3aaea216c1"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "c963c7db-b29e-4696-b850-9e3aaea216c1"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "c963c7db-b29e-4696-b850-9e3aaea216c1"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "c963c7db-b29e-4696-b850-9e3aaea216c1"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_4", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "9fd47688-8855-43cb-a0f7-10777a36c125"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "ad733296-6224-4884-b94d-dcbb9d26cff8"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "8a85d61a-6753-4d6d-a6f5-9f9ffb52666d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "8a85d61a-6753-4d6d-a6f5-9f9ffb52666d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ed59bb14-78ec-49f7-9951-f537ff581ca4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ed59bb14-78ec-49f7-9951-f537ff581ca4"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "ed59bb14-78ec-49f7-9951-f537ff581ca4"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "ed59bb14-78ec-49f7-9951-f537ff581ca4"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Text-area", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Text-area", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text area", "s-Text-area"]; 

	widgets.descriptionMap[["s-Paragraph_3", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_16", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Folder", "s-Image_16"]; 

	widgets.descriptionMap[["s-Bg", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_1", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Item_1", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_2", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Item_2", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_3", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Item_3", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Paragraph_4", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Image_17", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Done", "s-Image_17"]; 

	widgets.descriptionMap[["s-Paragraph_5", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Image_72", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_72", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Clear", "s-Image_72"]; 

	widgets.descriptionMap[["s-Button-black", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Image_3", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Send", "s-Image_3"]; 

	widgets.descriptionMap[["s-Paragraph_7", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "3b911434-f219-47e3-91f2-93612b9d4a8a"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_1", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Button-black", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Image_137", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_137", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_137"]; 

	widgets.descriptionMap[["s-Image_138", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_138", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_138"]; 

	widgets.descriptionMap[["s-Image_139", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_139", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_139"]; 

	widgets.descriptionMap[["s-Image_140", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_140", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_140"]; 

	widgets.descriptionMap[["s-Image_141", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_141", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_141"]; 

	widgets.descriptionMap[["s-Image_142", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_142", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_142"]; 

	widgets.descriptionMap[["s-Image_143", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_143", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_143"]; 

	widgets.descriptionMap[["s-Image_144", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Image_144", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Play Circle", "s-Image_144"]; 

	widgets.descriptionMap[["s-Paragraph_10", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "1ec06ea1-5fe6-47f2-86df-411be0efa241"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Image_4", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_3", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_1", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Input_1", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Check Box", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_4", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "8ccbb7e6-00fc-4874-9375-a991991a343d"]] = ["Paragraph", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Image_4", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-55840c41", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-55840c41", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_13", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_13", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-38253690", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-38253690", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_15", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_15", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-d1761289", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-d1761289", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_17", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_17", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-934bc694", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-934bc694", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_19", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_19", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-30161248", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-30161248", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_21", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_21", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-63c1d0cc", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-63c1d0cc", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Text_cell_23", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_23", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text Table", "s-Table_1"]; 

	widgets.descriptionMap[["s-Image_41", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Close blue button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Button-black", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Input_1", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Image_74", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "a89eb890-f116-4302-8a9b-a6067c7a14b7"]] = ["Group", "s-Image_74"]; 

	widgets.descriptionMap[["s-Paragraph_1", "62cecbf0-7e84-4308-b8f7-5bf049fe3273"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "62cecbf0-7e84-4308-b8f7-5bf049fe3273"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "62cecbf0-7e84-4308-b8f7-5bf049fe3273"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "62cecbf0-7e84-4308-b8f7-5bf049fe3273"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "62cecbf0-7e84-4308-b8f7-5bf049fe3273"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "62cecbf0-7e84-4308-b8f7-5bf049fe3273"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black_1", "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Button-black", "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "42ab1e1a-5249-4501-806a-dbc9ed3e3b5b"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ["Large button", "s-Button"]; 

	widgets.descriptionMap[["s-Button_1", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ["Large button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button_2", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "f5130a98-d53a-49ea-a238-10929f5f1195"]] = ["Large button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Category_2", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Image_4", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_2", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "5dfb0b9c-a1d5-46f5-83ff-c651935afa01"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "9a249b3e-9cda-45f8-8ea8-22b12d3c121b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "9a249b3e-9cda-45f8-8ea8-22b12d3c121b"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "9a249b3e-9cda-45f8-8ea8-22b12d3c121b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "9a249b3e-9cda-45f8-8ea8-22b12d3c121b"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "9a249b3e-9cda-45f8-8ea8-22b12d3c121b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "9a249b3e-9cda-45f8-8ea8-22b12d3c121b"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "e06d8014-6145-4b23-a5fe-c8b7f4004025"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Button", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ["Large button", "s-Button"]; 

	widgets.descriptionMap[["s-Button_1", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ["Large button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a844354a-2aab-49b8-892f-984837ef1518"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a844354a-2aab-49b8-892f-984837ef1518"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "a844354a-2aab-49b8-892f-984837ef1518"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "a844354a-2aab-49b8-892f-984837ef1518"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Category_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Custom Select List", "s-Category_2"]; 

	widgets.descriptionMap[["s-Image_12", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_12", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["File", "s-Image_12"]; 

	widgets.descriptionMap[["s-Bg", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_1", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Item_1", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Item_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Item_3", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Item_3", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Menu minimum width", "s-Menu-minimum-width"]; 

	widgets.descriptionMap[["s-Image_4", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Category_1", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Category_1", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Native dropdown", "s-Category_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "afea0b78-ce1c-4b33-9c62-d3408d7fc829"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a6172d59-27a9-4588-ab77-7e63dc105639"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a6172d59-27a9-4588-ab77-7e63dc105639"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "a6172d59-27a9-4588-ab77-7e63dc105639"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "a6172d59-27a9-4588-ab77-7e63dc105639"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "05bcb274-adda-4220-827d-659d690099a5"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "05bcb274-adda-4220-827d-659d690099a5"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "a5fe012e-0a3c-4e77-8cb2-977aa51b5c3a"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "47b84409-242f-4e09-942c-caf0ab5ce5dc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "47b84409-242f-4e09-942c-caf0ab5ce5dc"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "44c5a5ee-2a9b-4f6a-bb67-462ac651fa95"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "44c5a5ee-2a9b-4f6a-bb67-462ac651fa95"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_9", "44c5a5ee-2a9b-4f6a-bb67-462ac651fa95"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "44c5a5ee-2a9b-4f6a-bb67-462ac651fa95"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_1", "c78d41b0-d2d2-4733-bfd7-bbdd563e7685"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "c78d41b0-d2d2-4733-bfd7-bbdd563e7685"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black", "c78d41b0-d2d2-4733-bfd7-bbdd563e7685"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "c78d41b0-d2d2-4733-bfd7-bbdd563e7685"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black", "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_9", "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "ec9820f2-1a38-4f24-90a9-6f619de1e4d5"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_3", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button-black", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-checkbox_2", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ""; 

			widgets.rootWidgetMap[["s-checkbox_2", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ["Checkbox on light", "s-checkbox_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "a17f4ddd-841f-483b-bc3f-880cab6dc4bc"]] = ["Checkbox off", "s-checkbox-offLight_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "ad076817-9b66-42d0-b8bd-fda9ee3b9a2d"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "96d8da02-d9c0-4acd-a61f-465f76c11edd"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_4", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Radio Button Off", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image_2", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Radio Button On", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_22", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Image_22", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Mic filled", "s-Image_22"]; 

	widgets.descriptionMap[["s-Image_23", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Image_23", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Mute Mic", "s-Image_23"]; 

	widgets.descriptionMap[["s-Image_5", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Image_5", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Facecall filled", "s-Image_5"]; 

	widgets.descriptionMap[["s-Image_6", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Image_6", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Facecall filled", "s-Image_6"]; 

	widgets.descriptionMap[["s-Button-black", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Ellipse_1", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Ellipse", "s-Ellipse_1"]; 

	widgets.descriptionMap[["s-Input_1", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "bd022cbb-530d-4cb6-b026-12fd8af7cf91"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_1", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "fc5a2ddd-8b90-4f7e-a804-1338c55c261e"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "37a542a2-f31f-4d33-ad60-39863022745b"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "9c8a816b-cea5-4a91-8f7c-a5fe709e83fe"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "9c8a816b-cea5-4a91-8f7c-a5fe709e83fe"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Input_1", "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Input_2", "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "c8f4bbb4-5ef5-4aa4-a6a3-6f746e2855ec"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Button-black", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-checkbox_2", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ""; 

			widgets.rootWidgetMap[["s-checkbox_2", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ["Checkbox on light", "s-checkbox_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "ae14161c-89d7-45e2-ba6b-2d4197a8106c"]] = ["Checkbox off", "s-checkbox-offLight_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Button-black", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "5616f381-55b8-49cc-bec1-ea3bea0704c8"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Button-black_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Small button black", "s-Button-black_1"]; 

	widgets.descriptionMap[["s-Paragraph_1", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Ok-green", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Ok-green", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Ok green", "s-Ok-green"]; 

	widgets.descriptionMap[["s-Image_39", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Image_39", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Delete button", "s-Image_39"]; 

	widgets.descriptionMap[["s-Image_40", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Image_40", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Delete button", "s-Image_40"]; 

	widgets.descriptionMap[["s-Image_41", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Image_41", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Delete button", "s-Image_41"]; 

	widgets.descriptionMap[["s-Button-black", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Small button black", "s-Button-black"]; 

	widgets.descriptionMap[["s-Button-black_1", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ""; 

			widgets.rootWidgetMap[["s-Button-black_1", "bd231881-3a5f-4568-ba87-9e5db0b6f012"]] = ["Small button black", "s-Button-black_1"]; 

	