var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-5616f381-55b8-49cc-bec1-ea3bea0704c8" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer commentable non-processed" alignment="left" name="2_3_1 LECCIONES" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/5616f381-55b8-49cc-bec1-ea3bea0704c8-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/5616f381-55b8-49cc-bec1-ea3bea0704c8-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/5616f381-55b8-49cc-bec1-ea3bea0704c8-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="526.2px" datasizeheight="37.0px" dataX="270.0" dataY="119.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">- Necesidad de expresarse correctamente</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="306.2px" datasizeheight="37.0px" dataX="270.0" dataY="194.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">- Controlando los nervios</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="363.1px" datasizeheight="37.0px" dataX="270.0" dataY="275.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">- Transmisi&oacute;n eficaz de ideas</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="379.2px" datasizeheight="37.0px" dataX="270.0" dataY="350.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">- Partes de una exposici&oacute;n oral</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="476.1px" datasizeheight="37.0px" dataX="270.0" dataY="427.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">- Lenguaje gestual en la expresi&oacute;n oral</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="367.3px" datasizeheight="37.0px" dataX="270.0" dataY="506.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">- Preparaci&oacute;n de la exposici&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="404.7px" datasizeheight="37.0px" dataX="270.0" dataY="586.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">- Duraci&oacute;n de nuestra exposici&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="529.3px" datasizeheight="37.0px" dataX="270.0" dataY="655.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">- Exposici&oacute;n oral en funci&oacute;n de la audiencia</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="110.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="185.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="266.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="341.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="418.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="497.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_7" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="577.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_8" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="55.0px" datasizeheight="55.0px" dataX="204.0" dataY="646.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/47aecb44-2c29-431c-93ae-0462410b2ec9.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="566.0px" datasizeheight="74.0px" dataX="189.3" dataY="8.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">Visualiza las lecciones!!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Btn_Atr&aacute;s"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="8.0" dataY="707.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">ATR&Aacute;S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;