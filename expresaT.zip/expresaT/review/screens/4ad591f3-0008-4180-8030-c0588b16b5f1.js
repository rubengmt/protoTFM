var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-4ad591f3-0008-4180-8030-c0588b16b5f1" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="FF2_Fin VIsualizaci&oacute;nSinEv_nOTuSE" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4ad591f3-0008-4180-8030-c0588b16b5f1-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/4ad591f3-0008-4180-8030-c0588b16b5f1-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/4ad591f3-0008-4180-8030-c0588b16b5f1-1621273174462-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Mensaje_Fin_Parraf"   datasizewidth="862.3px" datasizeheight="260.0px" dataX="72.0" dataY="66.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">&iexcl;&iexcl;Grabaci&oacute;n realizada con &eacute;xito!!<br />Visualiza y/o escucha tu exposici&oacute;n y as&iacute; podr&aacute;s <br />ver en qu&eacute; partes puedes mejorar :)<br />Si la tarea requiere evaluaci&oacute;n no olvides enviarla.<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black_1" class="pie richtext manualfit firer click commentable non-processed" customid="Btn_Reintentar"   datasizewidth="304.0px" datasizeheight="51.0px" dataX="702.0" dataY="663.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_1_0">REPRODUCIR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Img_OK"   datasizewidth="465.5px" datasizeheight="314.0px" dataX="287.0" dataY="299.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1a629ac6-64f4-4da2-aa58-a4a771b5fe31.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="16.0" dataY="663.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;