var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-ec9820f2-1a38-4f24-90a9-6f619de1e4d5" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_2 PRACTICA" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ec9820f2-1a38-4f24-90a9-6f619de1e4d5-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/ec9820f2-1a38-4f24-90a9-6f619de1e4d5-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/ec9820f2-1a38-4f24-90a9-6f619de1e4d5-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="864.1px" datasizeheight="593.5px" dataX="79.9" dataY="87.3"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/75ebb425-fa20-41b8-bdb5-7c8b852060dd.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse_3" customid="Ellipse 3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="556.0" dataY="123.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_3)">\
                          <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 3" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_3" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_3_0">PON GESTOS</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_10" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="103.5" dataY="171.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_10)">\
                          <ellipse id="s-Ellipse_10" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_10" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_10_0">CUENTA HISTORIAS</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_11" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="827.0" dataY="246.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_11)">\
                          <ellipse id="s-Ellipse_11" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_11" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_11_0">DISCURSO EN MOVIMIENTO</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_4" customid="Ellipse 3" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="362.0" dataY="246.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_4)">\
                          <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 3" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_4" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_4_0">EXPOSICI&Oacute;N</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="12.0" dataY="709.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="334.9px" datasizeheight="74.0px" dataX="344.6" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">&iexcl;&iexcl;A practicar!!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;