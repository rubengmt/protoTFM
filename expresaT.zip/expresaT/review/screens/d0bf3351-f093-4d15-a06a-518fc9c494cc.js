var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620593424791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620593424791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d0bf3351-f093-4d15-a06a-518fc9c494cc" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_4_2 FORO" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d0bf3351-f093-4d15-a06a-518fc9c494cc-1620593424791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d0bf3351-f093-4d15-a06a-518fc9c494cc-1620593424791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d0bf3351-f093-4d15-a06a-518fc9c494cc-1620593424791-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed" customid="grab_off"   datasizewidth="108.0px" datasizeheight="99.4px" dataX="874.0" dataY="639.3"   alt="image" systemName="./images/2061a3e8-1cec-4cf8-915a-da06ba932f05.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_4-Layer_1" viewBox="0 0 64 64" width="64"><title>d</title><path d="M31.88,5.21a27,27,0,1,0,27,27A27,27,0,0,0,31.88,5.21Zm0,51.72A24.74,24.74,0,1,1,56.61,32.2,24.77,24.77,0,0,1,31.88,56.93Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer click ie-background commentable hidden non-processed" customid="grab_on"   datasizewidth="103.0px" datasizeheight="99.0px" dataX="876.5" dataY="639.5"   alt="image" systemName="./images/7c3aef5d-8360-4e03-8d92-38171ec9214f.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_2-Layer_1" viewBox="0 0 64 64" width="64"><title>a</title><path d="M31.88,5.21a27,27,0,1,0,27,27A27,27,0,0,0,31.88,5.21Zm0,51.72A24.74,24.74,0,1,1,56.61,32.2,24.77,24.77,0,0,1,31.88,56.93Z" fill="#A9A9A9" jimofill=" " /><circle cx="31.88" cy="32.2" r="15.63" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_22" class="pie image firer click ie-background commentable hidden non-processed" customid="mic_on"   datasizewidth="66.0px" datasizeheight="88.0px" dataX="521.0" dataY="645.0"   alt="image" systemName="./images/ada5405f-05ff-4832-a9a3-a831e70a945f.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 14 24" width="14px">\
          	    <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Dictation</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_22-iPhone-X" stroke="none" stroke-width="1" transform="translate(-88.000000, -194.000000)">\
          	        <path d="M98.7022235,217.999372 L98.7022235,218 L91.2946707,218 L91.2946707,217.999491 C91.2853779,217.999829 91.2760437,218 91.2666707,218 C90.837116,218 90.4888932,217.64179 90.4888932,217.199917 C90.4888932,216.758043 90.837116,216.399833 91.2666707,216.399833 C91.2760437,216.399833 91.2853779,216.400004 91.2946707,216.400342 L91.2946707,216.390232 L94.2315585,216.390232 L94.2315585,213.957979 C90.6761195,213.532933 87.9956768,210.432846 88.0000052,206.750828 C88.0000052,206.715624 88.0052941,206.683621 88.0059163,206.651618 L88.0059163,204.817746 C88.0020146,204.785265 88.0000052,204.752182 88.0000052,204.718616 C88.0000052,204.276742 88.3482281,203.918533 88.7777827,203.918533 C89.2073374,203.918533 89.5555602,204.276742 89.5555602,204.718616 C89.5555602,204.745237 89.5542963,204.771555 89.5518269,204.797508 L89.5518269,207.000454 L89.5477824,207.000454 L89.5477824,207.006855 C89.5477824,207.035658 89.5515158,207.064461 89.5518269,207.093264 L89.5518269,207.394095 L89.5664491,207.394095 C89.7976345,210.239545 92.0613257,212.457336 94.8354249,212.556233 L95.149647,212.556233 C97.9246342,212.458966 100.189569,210.240481 100.419867,207.394095 L100.438534,207.394095 L100.438534,204.728217 L100.444499,204.728175 C100.444463,204.724994 100.444445,204.721807 100.444445,204.718616 C100.444445,204.276742 100.792668,203.918533 101.222223,203.918533 C101.651777,203.918533 102,204.276742 102,204.718616 C102,204.741647 101.999054,204.76445 101.9972,204.786986 L101.9972,206.750828 L101.987867,206.750828 L101.987556,206.750828 C101.989997,210.426319 99.3194356,213.522707 95.7715579,213.957979 L95.7715579,216.390232 L98.7022235,216.390232 L98.7022235,216.400462 C98.7125434,216.400044 98.7229151,216.399833 98.7333346,216.399833 C99.1628892,216.399833 99.511112,216.758043 99.511112,217.199917 C99.511112,217.64179 99.1628892,218 98.7333346,218 C98.7229151,218 98.7125434,217.999789 98.7022235,217.999372 Z M99.1937788,205.403488 C99.1937788,205.886738 99.1937788,206.395591 99.1688899,206.878841 C99.1497844,207.314629 99.0851154,207.747033 98.9760011,208.168576 C98.732523,209.053368 98.2133352,209.831435 97.4982239,210.383206 C96.0314558,211.573674 93.9623272,211.573674 92.4955591,210.383206 C91.7785876,209.833144 91.2587575,209.054442 91.0171597,208.168576 C90.9075442,207.747152 90.8429693,207.31468 90.824582,206.878841 C90.7975153,206.395591 90.8000042,205.886738 90.8000042,205.403488 L90.8000042,201.358266 C90.8000042,200.878216 90.8024931,198.756395 90.8000042,198.397958 C90.8123002,197.959549 90.885639,197.525218 91.0177819,197.108223 C91.5158454,195.270887 93.1429467,194 94.9972026,194 C96.8514585,194 98.4785598,195.270887 98.9766234,197.108223 C99.0935859,197.528947 99.1665914,197.961304 99.194401,198.397958 C99.222401,198.881208 99.194401,200.878216 99.194401,201.358266 L99.194401,205.403488 L99.1937788,205.403488 Z" fill="#9B9B9B" id="s-Image_22-Dictation" style="fill:#A9A9A9 !important;" />\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_23" class="pie image firer click ie-background commentable hidden non-processed" customid="mic_off"   datasizewidth="65.0px" datasizeheight="88.0px" dataX="521.5" dataY="645.0"   alt="image" systemName="./images/61f63d74-8460-47c2-87f7-320cf270dd30.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 14 24" width="14px">\
          	    <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_23-iPhone-X" stroke="none" stroke-width="1" transform="translate(-88.000000, -239.000000)">\
          	        <path d="M96.5244154,257.290509 L97.2398242,258.567169 C96.7419421,258.757075 96.2161836,258.88999 95.6693021,258.957979 L95.6693021,261.390232 L98.5614068,261.390232 L98.5614068,261.400462 C98.571591,261.400044 98.5818262,261.399833 98.5921086,261.399833 C98.6840596,261.399833 98.7722342,261.416688 98.8539441,261.447595 L99.3493088,262.331582 C99.2890731,262.71081 98.9729892,263 98.5921086,263 C98.5818262,263 98.571591,262.999789 98.5614068,262.999372 L98.5614068,263 L91.2513204,263 L91.2513204,262.999491 C91.2421499,262.999829 91.2329385,263 91.2236888,263 C90.7997861,263 90.4561451,262.64179 90.4561451,262.199917 C90.4561451,261.758043 90.7997861,261.399833 91.2236888,261.399833 C91.2329385,261.399833 91.2421499,261.400004 91.2513204,261.400342 L91.2513204,261.390232 L94.1495655,261.390232 L94.1495655,258.957979 C90.640908,258.532933 87.9957337,255.432846 88.0000052,251.750828 C88.0000052,251.715624 88.0052245,251.683621 88.0058385,251.651618 L88.0058385,249.817746 C88.0019881,249.785265 88.0000052,249.752182 88.0000052,249.718616 C88.0000052,249.276742 88.3436462,248.918533 88.7675489,248.918533 C89.1914516,248.918533 89.5350926,249.276742 89.5350926,249.718616 C89.5350926,249.745237 89.5338454,249.771555 89.5314084,249.797508 L89.5314084,252.000454 L89.5274172,252.000454 L89.5274172,252.006855 C89.5274172,252.035658 89.5311014,252.064461 89.5314084,252.093264 L89.5314084,252.394095 L89.5458382,252.394095 C89.7739818,255.239545 92.007888,257.457336 94.7454865,257.556233 L95.0555741,257.556233 C95.5659147,257.538106 96.0587743,257.44631 96.5244154,257.290509 Z M99.4544967,254.912061 C99.8984507,254.172495 100.182822,253.316247 100.25645,252.394095 L100.274871,252.394095 L100.274871,249.728217 L100.280758,249.728175 C100.280723,249.724994 100.280705,249.721807 100.280705,249.718616 C100.280705,249.276742 100.624346,248.918533 101.048249,248.918533 C101.472151,248.918533 101.815792,249.276742 101.815792,249.718616 C101.815792,249.741647 101.814859,249.76445 101.813029,249.786986 L101.813029,251.750828 L101.803819,251.750828 L101.803512,251.750828 C101.804642,253.475522 101.224954,255.072705 100.247539,256.327259 L99.4544967,254.912061 Z M98.7017279,253.568732 L91.5586789,240.821834 C92.3052845,239.704111 93.5431126,239 94.9051355,239 C96.7349937,239 98.3406861,240.270887 98.8321963,242.108223 C98.9476199,242.528947 99.0196648,242.961304 99.0471085,243.397958 C99.0747401,243.881208 99.0471085,245.878216 99.0471085,246.358266 L99.0471085,250.403488 L99.0464945,250.403488 C99.0464945,250.886738 99.0464945,251.395591 99.0219331,251.878841 C99.003079,252.314629 98.9392608,252.747033 98.8315822,253.168576 C98.7946354,253.30463 98.7512552,253.43816 98.7017279,253.568732 Z M95.8846565,256.148848 C94.712205,256.45833 93.433322,256.203116 92.4364079,255.383206 C91.7288701,254.833144 91.2158798,254.054442 90.9774608,253.168576 C90.8692876,252.747152 90.8055624,252.31468 90.787417,251.878841 C90.7607064,251.395591 90.7631626,250.886738 90.7631626,250.403488 L90.7631626,247.009451 L95.8846565,256.148848 Z M88.1842078,240.494249 L89.5436625,239.48 L102,261.505751 L100.640545,262.52 L88.1842078,240.494249 Z" fill="#9B9B9B" id="s-Image_23-Icon" style="fill:#A9A9A9 !important;" />\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="pie image firer click ie-background commentable hidden non-processed" customid="cam_on"   datasizewidth="120.0px" datasizeheight="111.0px" dataX="313.0" dataY="633.5"   alt="image" systemName="./images/56fffe34-2224-44cf-96a8-bc08fb0dac66.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_5-Layer_1" viewBox="0 0 64 64" width="64"><title>3</title><path d="M38.05,17.39H10.92a3.13,3.13,0,0,0-3.13,3.13v23a3.14,3.14,0,0,0,3.13,3.13H38.05a3.14,3.14,0,0,0,3.13-3.13v-23A3.13,3.13,0,0,0,38.05,17.39Zm19.34,2.24a1,1,0,0,0-1,0L43.85,25.85a1,1,0,0,0-.58.94V37.22a1,1,0,0,0,.58.93l12.52,6.26a1.05,1.05,0,0,0,.47.11,1,1,0,0,0,1-1v-23A1,1,0,0,0,57.39,19.63Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable hidden non-processed" customid="cam_off_group" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed" customid="cam_off"   datasizewidth="120.0px" datasizeheight="111.0px" dataX="313.0" dataY="633.5"   alt="image" systemName="./images/af34ebca-7e71-4514-b198-3698545a3e1a.svg" overlay="#A9A9A9">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_6-Layer_1" viewBox="0 0 64 64" width="64"><title>3</title><path d="M38.05,17.39H10.92a3.13,3.13,0,0,0-3.13,3.13v23a3.14,3.14,0,0,0,3.13,3.13H38.05a3.14,3.14,0,0,0,3.13-3.13v-23A3.13,3.13,0,0,0,38.05,17.39Zm19.34,2.24a1,1,0,0,0-1,0L43.85,25.85a1,1,0,0,0-.58.94V37.22a1,1,0,0,0,.58.93l12.52,6.26a1.05,1.05,0,0,0,.47.11,1,1,0,0,0,1-1v-23A1,1,0,0,0,57.39,19.63Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="shapewrapper-s-Line_1" customid="cam_off_line" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="55" datasizewidth="115.1px" datasizeheight="6.0px" datasizewidthpx="115.12279469561732" datasizeheightpx="6.0" dataX="305.0" dataY="686.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_1" class="pie line shape non-processed-shape firer click ie-background commentable non-processed" customid="cam_off_line" d="M 0.0 3.0 L 115.12279469561732 3.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Image_39" class="pie image firer click ie-background commentable non-processed" customid="incluye_moltilla"   datasizewidth="84.0px" datasizeheight="78.0px" dataX="38.0" dataY="30.5"   alt="image" systemName="./images/37475b1f-a108-484a-9683-38e75d2faa8d.svg" overlay="#47CE5F">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" version="1" viewBox="0 0 24 24" width="24"><g><path d="M11.5 0c-6.341 0-11.5 5.159-11.5 11.5s5.159 11.5 11.5 11.5 11.5-5.159 11.5-11.5-5.159-11.5-11.5-11.5zm0 22c-5.79 0-10.5-4.71-10.5-10.5s4.71-10.5 10.5-10.5 10.5 4.71 10.5 10.5-4.71 10.5-10.5 10.5zM17.5 11h-5.5v-5.5c0-.276-.224-.5-.5-.5s-.5.224-.5.5v5.5h-5.5c-.276 0-.5.224-.5.5s.224.5.5.5h5.5v5.5c0 .276.224.5.5.5s.5-.224.5-.5v-5.5h5.5c.276 0 .5-.224.5-.5s-.224-.5-.5-.5z" fill="#47CE5F" jimofill=" " /></g></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable hidden non-processed" customid="Panel_Nueva_Entrada" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input-text_4" class="pie percentage textarea firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="text_muletillas"  datasizewidth="42.3%" datasizeheight="143.5px" dataX="47.0" dataY="209.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder=""></textarea></div></div></div>\
        <div id="s-Input_4" class="pie text firer commentable non-processed" customid="titulo"  datasizewidth="433.0px" datasizeheight="41.0px" dataX="47.0" dataY="168.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="NUEVA ENTRADA"/></div></div>  </div></div></div>\
\
        <div id="s-Image_40" class="pie image firer click ie-background commentable hidden non-processed" customid="cerrar_panel_mulet"   datasizewidth="41.0px" datasizeheight="41.0px" dataX="388.0" dataY="168.0"   alt="image" systemName="./images/a5900809-3dad-4d69-b139-2b74e5c69fd6.svg" overlay="#E2202C">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm4.588-7.102c.194.195.193.512-.002.707-.098.098-.225.146-.353.146-.127 0-.256-.049-.354-.146l-3.882-3.897-3.896 3.882c-.098.098-.226.146-.354.146-.127 0-.255-.049-.353-.146-.195-.196-.195-.513.001-.707l3.896-3.882-3.881-3.898c-.195-.197-.194-.513.002-.707.195-.197.512-.196.707 0l3.881 3.896 3.896-3.881c.195-.195.513-.195.707.001.195.195.195.512-.001.707l-3.896 3.882 3.882 3.897z" fill="#E2202C" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_3" class="group firer ie-background commentable hidden non-processed" customid="Panel_Visualizaci&oacute;n" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Table_1" class="pie table firer commentable hidden non-processed" customid="Tabla_resultados"  datasizewidth="686.0px" datasizeheight="365.4px" dataX="174.0" dataY="238.0" originalwidth="685.0000000000002px" originalheight="364.37894508932465px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <table summary="">\
                <tbody>\
                  <tr>\
                    <td id="s-Text_cell_13" class="pie textcell manualfit firer non-processed" customid="Text cell"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_13_0">Alumno</span></div></div></div></div></div></div>  </td>\
                    <td id="s-Text_cell_14" class="pie textcell manualfit firer non-processed" customid="Text cell"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_14_0">Duraci&oacute;n</span></div></div></div></div></div></div>  </td>\
                  </tr>\
                  <tr>\
                    <td id="s-Text_cell_15" class="pie textcell manualfit firer non-processed" customid="Text cell"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_15_0">Juan Perez Ruiz</span></div></div></div></div></div></div>  </td>\
                    <td id="s-Text_cell_16" class="pie textcell manualfit firer non-processed" customid="Text cell"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_16_0">03:33</span></div></div></div></div></div></div>  </td>\
                  </tr>\
                  <tr>\
                    <td id="s-Text_cell_17" class="pie textcell manualfit firer non-processed" customid="Text cell"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_17_0">Miriam Fuentes Sanz</span></div></div></div></div></div></div>  </td>\
                    <td id="s-Text_cell_18" class="pie textcell manualfit firer non-processed" customid="Text cell"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_18_0">08:15</span></div></div></div></div></div></div>  </td>\
                  </tr>\
                  <tr>\
                    <td id="s-Text_cell_19" class="pie textcell manualfit firer non-processed" customid="Text cell 7"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_19_0">Alvaro Gonzalez Puertas</span></div></div></div></div></div></div>  </td>\
                    <td id="s-Text_cell_20" class="pie textcell manualfit firer non-processed" customid="Text cell 8"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_20_0">05:06</span></div></div></div></div></div></div>  </td>\
                  </tr>\
                  <tr>\
                    <td id="s-Text_cell_21" class="pie textcell manualfit firer non-processed" customid="Text cell 9"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_21_0">Silvia Garc&iacute;a Alfonso</span></div></div></div></div></div></div>  </td>\
                    <td id="s-Text_cell_22" class="pie textcell manualfit firer non-processed" customid="Text cell 10"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_22_0">10:12</span></div></div></div></div></div></div>  </td>\
                  </tr>\
                  <tr>\
                    <td id="s-Text_cell_23" class="pie textcell manualfit firer non-processed" customid="Text cell 11"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_23_0">Noem&iacute; Sierra Herranz</span></div></div></div></div></div></div>  </td>\
                    <td id="s-Text_cell_24" class="pie textcell manualfit firer non-processed" customid="Text cell 12"     datasizewidth="343.5px" datasizeheight="61.7px" dataX="0.0" dataY="0.0" originalwidth="342.5000000000001px" originalheight="60.72982418155412px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_24_0">05:03</span></div></div></div></div></div></div>  </td>\
                  </tr>\
                </tbody>\
              </table>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_41" class="pie image firer click ie-background commentable hidden non-processed" customid="cerrar_tabla_resultados"   datasizewidth="52.1px" datasizeheight="46.6px" dataX="807.0" dataY="191.0"   alt="image" systemName="./images/5987dd97-0c9a-44df-877a-ceeea69a1141.svg" overlay="#E2202C">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm4.588-7.102c.194.195.193.512-.002.707-.098.098-.225.146-.353.146-.127 0-.256-.049-.354-.146l-3.882-3.897-3.896 3.882c-.098.098-.226.146-.354.146-.127 0-.255-.049-.353-.146-.195-.196-.195-.513.001-.707l3.896-3.882-3.881-3.898c-.195-.197-.194-.513.002-.707.195-.197.512-.196.707 0l3.881 3.896 3.896-3.881c.195-.195.513-.195.707.001.195.195.195.512-.001.707l-3.896 3.882 3.882 3.897z" fill="#E2202C" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Parraf_Results"   datasizewidth="512.9px" datasizeheight="74.0px" dataX="232.0" dataY="164.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Entradas disponibles</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_141" class="pie image firer click ie-background commentable non-processed" customid="Play1"   datasizewidth="47.5px" datasizeheight="43.8px" dataX="799.0" dataY="309.0"   alt="image" systemName="./images/906509b5-9acf-48d0-adf3-88ba8298bd01.svg" overlay="#1EAAF1">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1EAAF1" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_142" class="pie image firer click ie-background commentable non-processed" customid="Play2"   datasizewidth="47.5px" datasizeheight="43.8px" dataX="799.0" dataY="371.0"   alt="image" systemName="./images/e5c4f104-9416-4f7a-a298-c320414d4bab.svg" overlay="#1EAAF1">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1EAAF1" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_143" class="pie image firer click ie-background commentable non-processed" customid="Play3"   datasizewidth="47.5px" datasizeheight="43.8px" dataX="799.0" dataY="431.0"   alt="image" systemName="./images/bb326cbd-806a-4f46-abb8-2e6751400e74.svg" overlay="#1EAAF1">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1EAAF1" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_144" class="pie image firer click ie-background commentable non-processed" customid="Play4"   datasizewidth="47.5px" datasizeheight="43.8px" dataX="799.0" dataY="487.0"   alt="image" systemName="./images/aca052b5-0676-4f25-95de-1a280a5c331a.svg" overlay="#1EAAF1">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1EAAF1" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_145" class="pie image firer click ie-background commentable non-processed" customid="Play5"   datasizewidth="47.5px" datasizeheight="43.8px" dataX="799.0" dataY="552.0"   alt="image" systemName="./images/79d4dead-6332-417d-88db-e63b8ae3950f.svg" overlay="#1EAAF1">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1EAAF1" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Panel_Temas" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Category_2" class="pie dropdown firer commentable non-processed" customid="opciones_tema"    datasizewidth="544.0px" datasizeheight="48.0px" dataX="471.0" dataY="96.0"  tabindex="-1"><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Energ&iacute;as renovables</div></div></div></div></div><select id="s-Category_2-options" class="s-d0bf3351-f093-4d15-a06a-518fc9c494cc dropdown-options" ><option selected="selected" class="option">Energ&iacute;as renovables</option>\
        <option  class="option">Pr&aacute;cticas en ciberseguridad</option>\
        <option  class="option">Aplicaciones de circuitos neum&aacute;ticos</option></select></div>\
        <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Txt_Tema"   datasizewidth="186.2px" datasizeheight="48.0px" dataX="471.0" dataY="33.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_2_0">Elige Tema:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Btn_Atr&aacute;s"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="14.3" dataY="671.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">ATR&Aacute;S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_31" class="pie image firer click ie-background commentable non-processed" customid="Img_Visualiza"   datasizewidth="99.0px" datasizeheight="75.0px" dataX="174.5" dataY="32.0"   alt="image" systemName="./images/78e8e6e6-8274-47fa-ba6b-13724a34be60.svg" overlay="#1EAAF1">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" version="1" viewBox="0 0 24 24" width="24"><g><path d="M23.908 11.689c-.217-.273-5.374-6.689-11.892-6.689s-11.676 6.416-11.892 6.689c-.144.182-.144.439 0 .621.216.274 5.373 6.69 11.892 6.69s11.676-6.416 11.892-6.689c.144-.182.144-.44 0-.622zm-11.892 6.311c-5.247 0-9.734-4.729-10.845-6 1.111-1.271 5.598-6 10.845-6s9.734 4.729 10.845 6c-1.111 1.271-5.598 6-10.845 6zM12.016 7.5c-2.481 0-4.5 2.019-4.5 4.5s2.019 4.5 4.5 4.5 4.5-2.019 4.5-4.5-2.019-4.5-4.5-4.5zm0 8c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.571 3.5-3.5 3.5z" fill="#1EAAF1" jimofill=" " /></g></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_12" class="pie image firer click ie-background commentable hidden non-processed" customid="Carga_Fichero"   datasizewidth="79.0px" datasizeheight="83.0px" dataX="224.0" dataY="228.3"   alt="image" systemName="./images/96178d9c-08d6-4ff9-84c0-87b6778b4298.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_12-Layer_1" viewBox="0 0 64 64" width="64"><defs><style>#s-Image_12 .cls-1{fill:#A9A9A9 !important;}</style></defs><title>file</title><path class="cls-1" d="M51.71,17.29l-11-11A1,1,0,0,0,40,6H14a4,4,0,0,0-4,4V56a4,4,0,0,0,4,4H48a4,4,0,0,0,4-4V18A1,1,0,0,0,51.71,17.29ZM49.59,18H42a2,2,0,0,1-2-2V8.41ZM48,58H14a2,2,0,0,1-2-2V10a2,2,0,0,1,2-2H38v8a4,4,0,0,0,4,4h8V56A2,2,0,0,1,48,58ZM29,22H17a1,1,0,0,1,0-2H29A1,1,0,0,1,29,22Zm16,6H17a1,1,0,0,1,0-2H45A1,1,0,0,1,45,28Zm0,6H17a1,1,0,0,1,0-2H45A1,1,0,0,1,45,34Zm0,6H17a1,1,0,0,1,0-2H45A1,1,0,0,1,45,40Zm-6,6H17a1,1,0,0,1,0-2H39A1,1,0,0,1,39,46Z" id="s-Image_12-file" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Menu-minimum-width" class="group firer ie-background commentable hidden non-processed" customid="Menu_Carga_Entrada" datasizewidth="112.0px" datasizeheight="158.0px" >\
        <div id="s-Bg" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="312.0px" datasizeheight="159.0px" datasizewidthpx="311.9999999999999" datasizeheightpx="159.00000000000009" dataX="445.0" dataY="241.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Item_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Item_1"   datasizewidth="215.7px" datasizeheight="48.0px" datasizewidthpx="215.70370370370364" datasizeheightpx="48.0" dataX="445.0" dataY="249.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Item_1_0">Entrada Foro 1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Item_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Item_2"   datasizewidth="215.7px" datasizeheight="48.0px" datasizewidthpx="215.70370370370364" datasizeheightpx="48.0" dataX="445.0" dataY="296.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Item_2_0">Entrada Foro 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Item_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Item_3"   datasizewidth="215.7px" datasizeheight="48.0px" datasizewidthpx="215.70370370370364" datasizeheightpx="48.00000000000003" dataX="445.0" dataY="343.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Item_3_0">Entrada Foro 3</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable hidden non-processed" customid="Img_Sonido"   datasizewidth="900.7px" datasizeheight="401.1px" dataX="61.7" dataY="183.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/5c3bce08-6b19-46ab-9c9a-06193fcd0e59.gif" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;