var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-e06d8014-6145-4b23-a5fe-c8b7f4004025" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_3_4 Aprende LNV_0" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e06d8014-6145-4b23-a5fe-c8b7f4004025-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/e06d8014-6145-4b23-a5fe-c8b7f4004025-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/e06d8014-6145-4b23-a5fe-c8b7f4004025-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="752.4px" datasizeheight="118.0px" dataX="121.0" dataY="8.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Dadas las siguientes situaciones. <br />Responde a qu&eacute; estado corresponden. </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="401.0px" datasizeheight="401.0px" dataX="45.0" dataY="157.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/172b17ec-f769-4d06-b5fa-93a221d887ad.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_2" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="195.1px" datasizeheight="42.0px" dataX="570.0" dataY="253.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">a) Contenta</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="136.9px" datasizeheight="42.0px" dataX="570.0" dataY="327.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">b) Triste</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="205.4px" datasizeheight="42.0px" dataX="570.0" dataY="397.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">c) Pensativa</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="244.8px" datasizeheight="42.0px" dataX="570.0" dataY="463.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">c) Aterrorizada</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Ok-green" class="pie image firer ie-background commentable hidden non-processed" customid="Resp3_Ok"   datasizewidth="48.4px" datasizeheight="42.0px" dataX="806.0" dataY="397.0"   alt="image" systemName="./images/d493117b-8bb4-4730-81b9-3216b53d1489.svg" overlay="#47CF74">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 0c-6.617 0-12 5.384-12 12s5.383 12 12 12c6.616 0 12-5.384 12-12s-5.384-12-12-12zm5.341 8.866l-7.5 7c-.096.089-.219.134-.341.134-.129 0-.256-.049-.354-.146l-2.5-2.5c-.195-.195-.195-.512 0-.707s.512-.195.707 0l2.158 2.158 7.147-6.67c.201-.188.518-.179.707.023s.178.519-.024.708z" fill="#47CF74" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_39" class="pie image firer ie-background commentable hidden non-processed" customid="Resp4_KO"   datasizewidth="43.0px" datasizeheight="43.0px" dataX="839.0" dataY="462.0"   alt="image" systemName="./images/7c0dcd41-0273-4168-9147-b59d4ce0caf5.svg" overlay="#DD3214">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm6-10.488l-12.001-.012c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l12 .012c.276 0 .5.224.5.5-.001.276-.225.5-.5.5z" fill="#DD3214" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_40" class="pie image firer ie-background commentable hidden non-processed" customid="Resp2_KO"   datasizewidth="43.0px" datasizeheight="43.0px" dataX="732.4" dataY="326.5"   alt="image" systemName="./images/26d3bc04-a3a1-40c1-975a-9140f84f9588.svg" overlay="#DD3214">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm6-10.488l-12.001-.012c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l12 .012c.276 0 .5.224.5.5-.001.276-.225.5-.5.5z" fill="#DD3214" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_41" class="pie image firer ie-background commentable hidden non-processed" customid="Resp1_KO"   datasizewidth="43.0px" datasizeheight="43.0px" dataX="784.5" dataY="253.0"   alt="image" systemName="./images/89e37e42-18d9-47f7-8bbc-f08188a36fb2.svg" overlay="#DD3214">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm6-10.488l-12.001-.012c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l12 .012c.276 0 .5.224.5.5-.001.276-.225.5-.5.5z" fill="#DD3214" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="12.0" dataY="709.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black_1" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="241.2px" datasizeheight="51.0px" dataX="775.4" dataY="709.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_1_0">SIGUIENTE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;