var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-a17f4ddd-841f-483b-bc3f-880cab6dc4bc" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="FF9_FinForo" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a17f4ddd-841f-483b-bc3f-880cab6dc4bc-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/a17f4ddd-841f-483b-bc3f-880cab6dc4bc-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/a17f4ddd-841f-483b-bc3f-880cab6dc4bc-1621273174462-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Mensaje_Fin_Parraf"   datasizewidth="870.0px" datasizeheight="312.0px" dataX="77.0" dataY="41.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">&iexcl;&iexcl;Grabaci&oacute;n realizada con &eacute;xito!!<br />No olvides marcar la casilla de subir entrada antes de volver, si deseas incorporarla al foro.<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Img_OK"   datasizewidth="465.5px" datasizeheight="314.0px" dataX="293.0" dataY="241.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1a629ac6-64f4-4da2-aa58-a4a771b5fe31.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="69.0" dataY="695.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">VOLVER</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Txt_subir"   datasizewidth="216.3px" datasizeheight="48.0px" dataX="798.0" dataY="714.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Subir al foro.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-checkbox-offLight_1" class="group firer ie-background commentable non-processed" customid="Btn_Subir" datasizewidth="27.0px" datasizeheight="27.0px" >\
        <div id="s-checkbox_2" class="pie image firer click ie-background commentable hidden non-processed" customid="checkbox_1"   datasizewidth="40.0px" datasizeheight="40.7px" dataX="749.0" dataY="721.0"   alt="image" systemName="./images/af73d5aa-ba49-4fc9-9433-dc2a262518ca.svg" overlay="#6200EE">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<!-- Generator: Adobe Illustrator 21.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  --><svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="s-checkbox_2-Layer_1" style="enable-background:new 0 0 24 24;" version="1.1" viewBox="0 0 24 24" x="0px" xml:space="preserve" y="0px">\
            	<style type="text/css">\
            		#s-checkbox_2 .st0{fill:#6200EE !important;}\
            	</style>\
            	<g id="s-checkbox_2-check-box">\
            		<path class="st0" d="M19,3H5C3.9,3,3,3.9,3,5v14c0,1.1,0.9,2,2,2h14c1.1,0,2-0.9,2-2V5C21,3.9,20.1,3,19,3z M10,17l-5-5l1.4-1.4   l3.6,3.6l7.6-7.6L19,8L10,17z" fill="#6200EE" jimofill=" " />\
            	</g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Rectangle_3" class="pie rectangle manualfit firer click ie-background commentable non-processed" customid="Rectangle_2"   datasizewidth="34.1px" datasizeheight="34.6px" datasizewidthpx="34.07407407407413" datasizeheightpx="34.63260935830516" dataX="751.0" dataY="723.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;