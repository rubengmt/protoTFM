var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_4_3 PODCASTS" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/68cd7a31-3e0b-4b53-9d0e-e7d3a9fbcf4d-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Button" class="pie percentage richtext manualfit firer click commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Button"   datasizewidth="95.5%" datasizeheight="68.0px" dataX="0.0" dataY="278.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_0">Escucha Podcast</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="pie percentage richtext manualfit firer click commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Button"   datasizewidth="95.5%" datasizeheight="68.0px" dataX="0.0" dataY="451.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Crea Podcast</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="197.0px" datasizeheight="66.0px" dataX="425.2" dataY="35.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Podcasts</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="23.2" dataY="710.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="214.0px" datasizeheight="187.0px" dataX="739.0" dataY="68.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/bc18a5fd-e5a7-40f6-a517-f07265335c33.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="134.2px" datasizeheight="202.9px" dataX="36.0" dataY="60.1"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e7e496ab-90b9-4f5c-a109-d26328195605.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="223.0px" datasizeheight="208.0px" dataX="454.0" dataY="541.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/33b48bc3-d95c-46fb-ac3f-9a11c8d17a2b.png" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;