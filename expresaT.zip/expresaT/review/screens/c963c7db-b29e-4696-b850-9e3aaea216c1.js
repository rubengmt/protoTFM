var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-c963c7db-b29e-4696-b850-9e3aaea216c1" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="1_0_bis_Profe_Valida" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c963c7db-b29e-4696-b850-9e3aaea216c1-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/c963c7db-b29e-4696-b850-9e3aaea216c1-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/c963c7db-b29e-4696-b850-9e3aaea216c1-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1024.0px" datasizeheight="767.6px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/186b65d1-6de6-499f-9ec1-2facee30d20d.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse_9" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="845.0" dataY="600.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_9)">\
                          <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_9" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_9_0">SIGUIENTE</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_10" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="15.0" dataY="600.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_10)">\
                          <ellipse id="s-Ellipse_10" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_10" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_10_0">ATR&Aacute;S</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="476.0px" datasizeheight="88.0px" dataX="512.0" dataY="217.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Valida tu c&oacute;digo de profesor:"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie password firer commentable non-processed" customid="Input"  datasizewidth="310.0px" datasizeheight="62.0px" dataX="595.0" dataY="407.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div></div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;