var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-8ccbb7e6-00fc-4874-9375-a991991a343d" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_2_1 _2 Historia Imagenes" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/8ccbb7e6-00fc-4874-9375-a991991a343d-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/8ccbb7e6-00fc-4874-9375-a991991a343d-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/8ccbb7e6-00fc-4874-9375-a991991a343d-1621273174462-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed" customid="grab_off"   datasizewidth="108.0px" datasizeheight="99.4px" dataX="874.0" dataY="639.3"   alt="image" systemName="./images/d19c18a3-517e-466f-8510-39d669640bf5.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_4-Layer_1" viewBox="0 0 64 64" width="64"><title>d</title><path d="M31.88,5.21a27,27,0,1,0,27,27A27,27,0,0,0,31.88,5.21Zm0,51.72A24.74,24.74,0,1,1,56.61,32.2,24.77,24.77,0,0,1,31.88,56.93Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer click ie-background commentable hidden non-processed" customid="grab_on"   datasizewidth="103.0px" datasizeheight="99.0px" dataX="876.5" dataY="639.5"   alt="image" systemName="./images/6cc16ab0-d91e-4049-8d7e-e4fa1db3f596.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_2-Layer_1" viewBox="0 0 64 64" width="64"><title>a</title><path d="M31.88,5.21a27,27,0,1,0,27,27A27,27,0,0,0,31.88,5.21Zm0,51.72A24.74,24.74,0,1,1,56.61,32.2,24.77,24.77,0,0,1,31.88,56.93Z" fill="#A9A9A9" jimofill=" " /><circle cx="31.88" cy="32.2" r="15.63" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_22" class="pie image firer click ie-background commentable non-processed" customid="mic_on"   datasizewidth="66.0px" datasizeheight="88.0px" dataX="521.0" dataY="645.0"   alt="image" systemName="./images/b73f76a9-6731-4159-adf1-ace71606601f.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 14 24" width="14px">\
          	    <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Dictation</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_22-iPhone-X" stroke="none" stroke-width="1" transform="translate(-88.000000, -194.000000)">\
          	        <path d="M98.7022235,217.999372 L98.7022235,218 L91.2946707,218 L91.2946707,217.999491 C91.2853779,217.999829 91.2760437,218 91.2666707,218 C90.837116,218 90.4888932,217.64179 90.4888932,217.199917 C90.4888932,216.758043 90.837116,216.399833 91.2666707,216.399833 C91.2760437,216.399833 91.2853779,216.400004 91.2946707,216.400342 L91.2946707,216.390232 L94.2315585,216.390232 L94.2315585,213.957979 C90.6761195,213.532933 87.9956768,210.432846 88.0000052,206.750828 C88.0000052,206.715624 88.0052941,206.683621 88.0059163,206.651618 L88.0059163,204.817746 C88.0020146,204.785265 88.0000052,204.752182 88.0000052,204.718616 C88.0000052,204.276742 88.3482281,203.918533 88.7777827,203.918533 C89.2073374,203.918533 89.5555602,204.276742 89.5555602,204.718616 C89.5555602,204.745237 89.5542963,204.771555 89.5518269,204.797508 L89.5518269,207.000454 L89.5477824,207.000454 L89.5477824,207.006855 C89.5477824,207.035658 89.5515158,207.064461 89.5518269,207.093264 L89.5518269,207.394095 L89.5664491,207.394095 C89.7976345,210.239545 92.0613257,212.457336 94.8354249,212.556233 L95.149647,212.556233 C97.9246342,212.458966 100.189569,210.240481 100.419867,207.394095 L100.438534,207.394095 L100.438534,204.728217 L100.444499,204.728175 C100.444463,204.724994 100.444445,204.721807 100.444445,204.718616 C100.444445,204.276742 100.792668,203.918533 101.222223,203.918533 C101.651777,203.918533 102,204.276742 102,204.718616 C102,204.741647 101.999054,204.76445 101.9972,204.786986 L101.9972,206.750828 L101.987867,206.750828 L101.987556,206.750828 C101.989997,210.426319 99.3194356,213.522707 95.7715579,213.957979 L95.7715579,216.390232 L98.7022235,216.390232 L98.7022235,216.400462 C98.7125434,216.400044 98.7229151,216.399833 98.7333346,216.399833 C99.1628892,216.399833 99.511112,216.758043 99.511112,217.199917 C99.511112,217.64179 99.1628892,218 98.7333346,218 C98.7229151,218 98.7125434,217.999789 98.7022235,217.999372 Z M99.1937788,205.403488 C99.1937788,205.886738 99.1937788,206.395591 99.1688899,206.878841 C99.1497844,207.314629 99.0851154,207.747033 98.9760011,208.168576 C98.732523,209.053368 98.2133352,209.831435 97.4982239,210.383206 C96.0314558,211.573674 93.9623272,211.573674 92.4955591,210.383206 C91.7785876,209.833144 91.2587575,209.054442 91.0171597,208.168576 C90.9075442,207.747152 90.8429693,207.31468 90.824582,206.878841 C90.7975153,206.395591 90.8000042,205.886738 90.8000042,205.403488 L90.8000042,201.358266 C90.8000042,200.878216 90.8024931,198.756395 90.8000042,198.397958 C90.8123002,197.959549 90.885639,197.525218 91.0177819,197.108223 C91.5158454,195.270887 93.1429467,194 94.9972026,194 C96.8514585,194 98.4785598,195.270887 98.9766234,197.108223 C99.0935859,197.528947 99.1665914,197.961304 99.194401,198.397958 C99.222401,198.881208 99.194401,200.878216 99.194401,201.358266 L99.194401,205.403488 L99.1937788,205.403488 Z" fill="#9B9B9B" id="s-Image_22-Dictation" style="fill:#A9A9A9 !important;" />\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_23" class="pie image firer click ie-background commentable hidden non-processed" customid="mic_off"   datasizewidth="65.0px" datasizeheight="88.0px" dataX="521.5" dataY="645.0"   alt="image" systemName="./images/2c71024b-53a8-47b1-b88f-8d56335d4e08.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="24px" version="1.1" viewBox="0 0 14 24" width="14px">\
          	    <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_23-iPhone-X" stroke="none" stroke-width="1" transform="translate(-88.000000, -239.000000)">\
          	        <path d="M96.5244154,257.290509 L97.2398242,258.567169 C96.7419421,258.757075 96.2161836,258.88999 95.6693021,258.957979 L95.6693021,261.390232 L98.5614068,261.390232 L98.5614068,261.400462 C98.571591,261.400044 98.5818262,261.399833 98.5921086,261.399833 C98.6840596,261.399833 98.7722342,261.416688 98.8539441,261.447595 L99.3493088,262.331582 C99.2890731,262.71081 98.9729892,263 98.5921086,263 C98.5818262,263 98.571591,262.999789 98.5614068,262.999372 L98.5614068,263 L91.2513204,263 L91.2513204,262.999491 C91.2421499,262.999829 91.2329385,263 91.2236888,263 C90.7997861,263 90.4561451,262.64179 90.4561451,262.199917 C90.4561451,261.758043 90.7997861,261.399833 91.2236888,261.399833 C91.2329385,261.399833 91.2421499,261.400004 91.2513204,261.400342 L91.2513204,261.390232 L94.1495655,261.390232 L94.1495655,258.957979 C90.640908,258.532933 87.9957337,255.432846 88.0000052,251.750828 C88.0000052,251.715624 88.0052245,251.683621 88.0058385,251.651618 L88.0058385,249.817746 C88.0019881,249.785265 88.0000052,249.752182 88.0000052,249.718616 C88.0000052,249.276742 88.3436462,248.918533 88.7675489,248.918533 C89.1914516,248.918533 89.5350926,249.276742 89.5350926,249.718616 C89.5350926,249.745237 89.5338454,249.771555 89.5314084,249.797508 L89.5314084,252.000454 L89.5274172,252.000454 L89.5274172,252.006855 C89.5274172,252.035658 89.5311014,252.064461 89.5314084,252.093264 L89.5314084,252.394095 L89.5458382,252.394095 C89.7739818,255.239545 92.007888,257.457336 94.7454865,257.556233 L95.0555741,257.556233 C95.5659147,257.538106 96.0587743,257.44631 96.5244154,257.290509 Z M99.4544967,254.912061 C99.8984507,254.172495 100.182822,253.316247 100.25645,252.394095 L100.274871,252.394095 L100.274871,249.728217 L100.280758,249.728175 C100.280723,249.724994 100.280705,249.721807 100.280705,249.718616 C100.280705,249.276742 100.624346,248.918533 101.048249,248.918533 C101.472151,248.918533 101.815792,249.276742 101.815792,249.718616 C101.815792,249.741647 101.814859,249.76445 101.813029,249.786986 L101.813029,251.750828 L101.803819,251.750828 L101.803512,251.750828 C101.804642,253.475522 101.224954,255.072705 100.247539,256.327259 L99.4544967,254.912061 Z M98.7017279,253.568732 L91.5586789,240.821834 C92.3052845,239.704111 93.5431126,239 94.9051355,239 C96.7349937,239 98.3406861,240.270887 98.8321963,242.108223 C98.9476199,242.528947 99.0196648,242.961304 99.0471085,243.397958 C99.0747401,243.881208 99.0471085,245.878216 99.0471085,246.358266 L99.0471085,250.403488 L99.0464945,250.403488 C99.0464945,250.886738 99.0464945,251.395591 99.0219331,251.878841 C99.003079,252.314629 98.9392608,252.747033 98.8315822,253.168576 C98.7946354,253.30463 98.7512552,253.43816 98.7017279,253.568732 Z M95.8846565,256.148848 C94.712205,256.45833 93.433322,256.203116 92.4364079,255.383206 C91.7288701,254.833144 91.2158798,254.054442 90.9774608,253.168576 C90.8692876,252.747152 90.8055624,252.31468 90.787417,251.878841 C90.7607064,251.395591 90.7631626,250.886738 90.7631626,250.403488 L90.7631626,247.009451 L95.8846565,256.148848 Z M88.1842078,240.494249 L89.5436625,239.48 L102,261.505751 L100.640545,262.52 L88.1842078,240.494249 Z" fill="#9B9B9B" id="s-Image_23-Icon" style="fill:#A9A9A9 !important;" />\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="pie image firer click ie-background commentable non-processed" customid="cam_on"   datasizewidth="120.0px" datasizeheight="111.0px" dataX="313.0" dataY="633.5"   alt="image" systemName="./images/32b34305-da36-49af-8cbc-3a4b9b43363f.svg" overlay="#A9A9A9">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_5-Layer_1" viewBox="0 0 64 64" width="64"><title>3</title><path d="M38.05,17.39H10.92a3.13,3.13,0,0,0-3.13,3.13v23a3.14,3.14,0,0,0,3.13,3.13H38.05a3.14,3.14,0,0,0,3.13-3.13v-23A3.13,3.13,0,0,0,38.05,17.39Zm19.34,2.24a1,1,0,0,0-1,0L43.85,25.85a1,1,0,0,0-.58.94V37.22a1,1,0,0,0,.58.93l12.52,6.26a1.05,1.05,0,0,0,.47.11,1,1,0,0,0,1-1v-23A1,1,0,0,0,57.39,19.63Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable hidden non-processed" customid="cam_off_group" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed" customid="cam_off"   datasizewidth="120.0px" datasizeheight="111.0px" dataX="313.0" dataY="633.5"   alt="image" systemName="./images/98569544-de24-408f-9f42-74abda1017d0.svg" overlay="#A9A9A9">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" data-name="Layer 1" height="64" id="s-Image_6-Layer_1" viewBox="0 0 64 64" width="64"><title>3</title><path d="M38.05,17.39H10.92a3.13,3.13,0,0,0-3.13,3.13v23a3.14,3.14,0,0,0,3.13,3.13H38.05a3.14,3.14,0,0,0,3.13-3.13v-23A3.13,3.13,0,0,0,38.05,17.39Zm19.34,2.24a1,1,0,0,0-1,0L43.85,25.85a1,1,0,0,0-.58.94V37.22a1,1,0,0,0,.58.93l12.52,6.26a1.05,1.05,0,0,0,.47.11,1,1,0,0,0,1-1v-23A1,1,0,0,0,57.39,19.63Z" fill="#A9A9A9" jimofill=" " /></svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="shapewrapper-s-Line_1" customid="cam_off_line" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="55" datasizewidth="115.1px" datasizeheight="6.0px" datasizewidthpx="115.12279469561732" datasizeheightpx="6.0" dataX="305.0" dataY="686.0" >\
            <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
                <g>\
                    <g>\
                        <path id="s-Line_1" class="pie line shape non-processed-shape firer click ie-background commentable non-processed" customid="cam_off_line" d="M 0.0 3.0 L 115.12279469561732 3.0"  >\
                        </path>\
                    </g>\
                </g>\
                <defs>\
                </defs>\
            </svg>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable hidden non-processed" customid="imagen_grabacion"   datasizewidth="574.5px" datasizeheight="366.5px" dataX="224.7" dataY="309.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c953b6f7-de85-4e43-a95e-f33ac9242a8e.gif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Btn_Atr&aacute;s"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="15.0" dataY="663.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">ATR&Aacute;S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Mensaje_Fin_Parraf"   datasizewidth="932.4px" datasizeheight="208.0px" dataX="55.0" dataY="66.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">&iexcl;&iexcl;Grabaci&oacute;n realizada con &eacute;xito!!<br />Visualiza tu exposici&oacute;n y as&iacute; podr&aacute;s ver en qu&eacute; partes <br />puedes mejorar :)<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable hidden non-processed" customid="Img_OK"   datasizewidth="465.5px" datasizeheight="314.0px" dataX="306.0" dataY="264.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1a629ac6-64f4-4da2-aa58-a4a771b5fe31.jpg" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Panel_Imagenes" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Palabras_Parraf"   datasizewidth="638.0px" datasizeheight="104.0px" dataX="40.0" dataY="19.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">Las im&aacute;genes que debes utilizar son: <br /><br /></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_7" class="pie image firer ie-background commentable non-processed" customid="Image 7"   datasizewidth="319.3px" datasizeheight="224.5px" dataX="24.0" dataY="70.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/8e9c78aa-1845-4812-b7e4-56eaa1d447b5.jpg" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_8" class="pie image firer ie-background commentable non-processed" customid="Image 8"   datasizewidth="316.1px" datasizeheight="225.2px" dataX="363.0" dataY="70.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/6f5013b0-29ba-4638-b67a-ffe48ea38e71.jpg" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_9" class="pie image firer ie-background commentable non-processed" customid="Image 9"   datasizewidth="297.0px" datasizeheight="224.0px" dataX="703.0" dataY="71.0"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/ac9611ae-6e08-4fa7-8828-94227e50d7c4.jpg" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
\
        <div id="s-Input_1" class="pie inputIOS checkbox firer commentable non-processed" customid="Check_Grupo"  datasizewidth="21.0px" datasizeheight="21.0px" dataX="874.0" dataY="9.0"      tabindex="-1">\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="checkBoxiOS"></div>\
        </div>\
\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Txt_Check_Engrupo"   datasizewidth="111.7px" datasizeheight="37.0px" dataX="903.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">En Grupo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext manualfit firer ie-background commentable hidden non-processed" customid="Parraf_FinGrupo"   datasizewidth="974.8px" datasizeheight="228.0px" dataX="49.2" dataY="367.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">El turno ha pasado a uno de tus compa&ntilde;eros de grupo. Puedes detener la emisi&oacute;n.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;