var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-47b84409-242f-4e09-942c-caf0ab5ce5dc" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="1_2_1 Menu_Profesor" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/47b84409-242f-4e09-942c-caf0ab5ce5dc-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/47b84409-242f-4e09-942c-caf0ab5ce5dc-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/47b84409-242f-4e09-942c-caf0ab5ce5dc-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="233.6px" datasizeheight="74.0px" dataX="378.0" dataY="70.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">expresaT</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="39.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 1" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0">PODCAST</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="78.0" dataY="275.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0">DEBATE</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_3" customid="Ellipse 3" class="shapewrapper shapewrapper-s-Ellipse_3 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="375.0" dataY="200.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_3" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_3)">\
                          <ellipse id="s-Ellipse_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 3" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_3" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_3" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_3_0">PON GESTOS</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_4" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_4 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="832.0" dataY="459.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_4" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_4)">\
                          <ellipse id="s-Ellipse_4" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_4" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_4" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_4_0">APRENDE</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_6" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_6 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="352.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_6" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_6)">\
                          <ellipse id="s-Ellipse_6" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_6" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_6" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_6_0">FORO</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_7" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_7 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="617.0" dataY="550.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_7" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_7)">\
                          <ellipse id="s-Ellipse_7" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_7" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_7" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_7_0">RADIO</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_8" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_8 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="478.0" dataY="378.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_8" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_8)">\
                          <ellipse id="s-Ellipse_8" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_8" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_8" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_8_0">JUEGO</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_9" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_9 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="656.0" dataY="158.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_9" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_9)">\
                          <ellipse id="s-Ellipse_9" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_9" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_9" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_9_0">PROFESOR</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_10" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_10 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="246.0" dataY="400.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_10" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_10)">\
                          <ellipse id="s-Ellipse_10" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_10" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_10" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_10_0">CUENTA HISTORIAS</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;