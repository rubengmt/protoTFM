var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-3b911434-f219-47e3-91f2-93612b9d4a8a" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="FF4_1 Evaluaci&oacute;n profesor" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/3b911434-f219-47e3-91f2-93612b9d4a8a-1621273174462.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/3b911434-f219-47e3-91f2-93612b9d4a8a-1621273174462-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/3b911434-f219-47e3-91f2-93612b9d4a8a-1621273174462-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Txt_Inicial1"   datasizewidth="579.7px" datasizeheight="74.0px" dataX="222.2" dataY="40.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Evaluaci&oacute;n del profesor</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Tct_Inicial2"   datasizewidth="692.4px" datasizeheight="148.0px" dataX="165.8" dataY="123.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">No olvides enviar el archivo.<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text-area" class="pie percentage textarea firer commentable pin hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Text-area"  datasizewidth="95.9%" datasizeheight="150.0px" dataX="20.0" dataY="359.8" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder=""></textarea></div></div></div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Txt_Adjunta"   datasizewidth="356.3px" datasizeheight="66.0px" dataX="353.0" dataY="292.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Adjunta archivo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_16" class="pie image firer click ie-background commentable non-processed" customid="Img_Carpeta"   datasizewidth="71.0px" datasizeheight="68.0px" dataX="931.0" dataY="291.8"   alt="image" systemName="./images/9572c6cb-fcbb-450e-a000-468e4eaaf2d7.svg" overlay="#6FAEEF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z" fill="#6FAEEF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Menu-minimum-width" class="group firer ie-background commentable hidden non-processed" customid="Menu_Mis_Archivos" datasizewidth="112.0px" datasizeheight="158.0px" >\
        <div id="s-Bg" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="312.0px" datasizeheight="159.0px" datasizewidthpx="311.9999999999999" datasizeheightpx="159.00000000000009" dataX="690.0" dataY="395.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Bg_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Item_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Item_1"   datasizewidth="215.7px" datasizeheight="48.0px" datasizewidthpx="215.70370370370364" datasizeheightpx="48.0" dataX="690.0" dataY="403.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Item_1_0">Archivo 1</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Item_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Item_2"   datasizewidth="215.7px" datasizeheight="48.0px" datasizewidthpx="215.70370370370364" datasizeheightpx="48.0" dataX="690.0" dataY="450.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Item_2_0">Archivo 2</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Item_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Item_3"   datasizewidth="215.7px" datasizeheight="48.0px" datasizewidthpx="215.70370370370364" datasizeheightpx="48.00000000000003" dataX="690.0" dataY="497.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Item_3_0">Archivo 3</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Arch1_Txt"   datasizewidth="162.2px" datasizeheight="52.0px" dataX="108.0" dataY="395.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Archivo 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_17" class="pie image firer ie-background commentable hidden non-processed" customid="Img_Validado"   datasizewidth="53.0px" datasizeheight="46.0px" dataX="300.0" dataY="398.0"   alt="image" systemName="./images/05351011-e63c-4fa3-8ad3-279cbf3392fd.svg" overlay="#3FE859">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z" fill="#3FE859" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Arch2_Txt"   datasizewidth="168.2px" datasizeheight="52.0px" dataX="108.0" dataY="395.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Archivo 2</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Arch3_Txt"   datasizewidth="168.2px" datasizeheight="52.0px" dataX="105.0" dataY="395.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Archivo 3</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_72" class="pie image firer click ie-background commentable non-processed" customid="Img_Clear"   datasizewidth="64.0px" datasizeheight="63.0px" dataX="20.0" dataY="446.8"   alt="image" systemName="./images/7c14cc3b-f727-45d4-a679-01564b8a14f4.svg" overlay="#EF1717">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" fill="#EF1717" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Btn_Menu"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="20.0" dataY="707.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed" customid="Btn_Enviar"   datasizewidth="62.0px" datasizeheight="55.0px" dataX="920.0" dataY="450.8"   alt="image" systemName="./images/ab21e341-064a-4d30-bbc8-fd72228871b1.svg" overlay="#27CD33">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" fill="#27CD33" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable hidden non-processed" customid="Img_Envio_Exito"   datasizewidth="1015.0px" datasizeheight="631.0px" dataX="9.0" dataY="68.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b0ed3c56-0861-4238-a532-6087889fbc83.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Txt_Envio_Exito"   datasizewidth="1025.6px" datasizeheight="89.0px" dataX="9.0" dataY="57.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">La tarea ha sido enviada con &eacute;xito.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;