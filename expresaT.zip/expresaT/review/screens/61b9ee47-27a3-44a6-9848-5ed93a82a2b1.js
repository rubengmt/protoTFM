var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620593424791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620593424791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-61b9ee47-27a3-44a6-9848-5ed93a82a2b1" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_3 APRENDE" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/61b9ee47-27a3-44a6-9848-5ed93a82a2b1-1620593424791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/61b9ee47-27a3-44a6-9848-5ed93a82a2b1-1620593424791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/61b9ee47-27a3-44a6-9848-5ed93a82a2b1-1620593424791-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="537.0px" datasizeheight="599.0px" dataX="253.7" dataY="123.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/fd636c4a-a6c2-4b90-b9cb-93cdf3e6192f.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse_11" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_11 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="45.0" dataY="137.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_11" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_11)">\
                          <ellipse id="s-Ellipse_11" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_11" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_11" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_11_0">DETECTA COLETILLAS</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_12" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_12 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="830.0" dataY="137.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_12" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_12)">\
                          <ellipse id="s-Ellipse_12" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_12" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_12" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_12_0">LECCIONES</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_13" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_13 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="45.0" dataY="527.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_13" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_13)">\
                          <ellipse id="s-Ellipse_13" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_13" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_13" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_13_0">LENGUAJE NO VERBAL</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="330.4px" datasizeheight="74.0px" dataX="356.9" dataY="32.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">&iexcl;&iexcl;A aprender!!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="12.0" dataY="709.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_14" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_14 non-processed"   datasizewidth="150.0px" datasizeheight="150.0px" datasizewidthpx="150.0" datasizeheightpx="150.0" dataX="830.0" dataY="527.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_14" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_14)">\
                          <ellipse id="s-Ellipse_14" class="pie ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Ellipse 2" cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_14" class="clipPath">\
                          <ellipse cx="75.0" cy="75.0" rx="75.0" ry="75.0">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_14" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_14_0">ENTONACI&Oacute;N</span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;