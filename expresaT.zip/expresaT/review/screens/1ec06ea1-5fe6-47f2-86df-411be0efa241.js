var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620593424791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620593424791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-1ec06ea1-5fe6-47f2-86df-411be0efa241" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer commentable non-processed" alignment="left" name="2_4_3_1 Escuchar Podcast" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1ec06ea1-5fe6-47f2-86df-411be0efa241-1620593424791.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/1ec06ea1-5fe6-47f2-86df-411be0efa241-1620593424791-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/1ec06ea1-5fe6-47f2-86df-411be0efa241-1620593424791-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="310.0px" datasizeheight="44.0px" dataX="628.0" dataY="250.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">- An&eacute;cdotas del aula.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="240.1px" datasizeheight="44.0px" dataX="116.0" dataY="338.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">- Hablando bien.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="303.3px" datasizeheight="44.0px" dataX="628.0" dataY="334.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">- Museos de Madrid.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="254.4px" datasizeheight="44.0px" dataX="628.0" dataY="430.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">- Deporte y Aula.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="347.0px" datasizeheight="44.0px" dataX="116.0" dataY="434.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">- A golpe de tecnolog&iacute;a.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="344.1px" datasizeheight="44.0px" dataX="116.0" dataY="529.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">- Avances de la ciencia.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="221.9px" datasizeheight="44.0px" dataX="628.0" dataY="524.9" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">- Saber comer.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="351.2px" datasizeheight="44.0px" dataX="116.0" dataY="246.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">- Matem&aacute;ticas al Poder.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="452.8px" datasizeheight="59.0px" dataX="272.0" dataY="47.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">Fonoteca de Podcasts. </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Btn_Atr&aacute;s"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="8.0" dataY="707.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">ATR&Aacute;S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_137" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="47.8" dataY="338.0"   alt="image" systemName="./images/bda86ae0-8156-4f92-9e0c-d5bb50cf5136.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_138" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="47.8" dataY="241.1"   alt="image" systemName="./images/af7e3ecb-b527-4f6d-a8d0-e516bb4b6691.svg" overlay="#1CDBD6">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD6" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_139" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="50.0" dataY="434.0"   alt="image" systemName="./images/baf6a0ce-4fa2-4d71-b35c-b2317781d8ab.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_140" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="50.0" dataY="529.0"   alt="image" systemName="./images/873483dd-289e-4fed-ae8c-f533b2b73084.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_141" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="557.0" dataY="246.0"   alt="image" systemName="./images/31d4a69c-1cb0-4117-9033-d39926378f06.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_142" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="557.0" dataY="334.9"   alt="image" systemName="./images/ebaecbce-e028-4d48-917d-6ad5fad545fb.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_143" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="557.0" dataY="426.0"   alt="image" systemName="./images/32d02d4e-53dc-4d1b-a3cb-4d8fe2f2bd5f.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_144" class="pie image firer click ie-background commentable non-processed" customid="Image_137"   datasizewidth="59.5px" datasizeheight="53.8px" dataX="557.0" dataY="520.0"   alt="image" systemName="./images/5fff78bf-37c0-411a-906f-83f822ae17a5.svg" overlay="#1CDBD7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z" fill="#1CDBD7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="109.7px" datasizeheight="29.0px" dataX="899.0" dataY="718.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">Hoja 1 de 1</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;