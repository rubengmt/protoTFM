var content='<div class="ui-page" deviceName="ipad" deviceType="mobile" deviceWidth="768" deviceHeight="1024">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-bd231881-3a5f-4568-ba87-9e5db0b6f012" class="screen growth-vertical devMobile devIOS canvas LANDSCAPE firer ie-background commentable non-processed" alignment="left" name="2_3_4 Aprende LNV_1" width="768" height="1024">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/bd231881-3a5f-4568-ba87-9e5db0b6f012-1620811406670.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/bd231881-3a5f-4568-ba87-9e5db0b6f012-1620811406670-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/bd231881-3a5f-4568-ba87-9e5db0b6f012-1620811406670-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="752.4px" datasizeheight="118.0px" dataX="121.0" dataY="8.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Dadas las siguientes situaciones. <br />Responde a qu&eacute; estado corresponden. </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="203.4px" datasizeheight="42.0px" dataX="570.0" dataY="253.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">a) Enfadada</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="136.9px" datasizeheight="42.0px" dataX="570.0" dataY="327.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">b) Triste</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="149.4px" datasizeheight="42.0px" dataX="570.0" dataY="397.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">c) Alegre</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer click ie-background commentable non-processed" customid="Paragraph"   datasizewidth="190.9px" datasizeheight="42.0px" dataX="570.0" dataY="463.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">c) Confiada</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Ok-green" class="pie image firer ie-background commentable hidden non-processed" customid="Resp1_Ok"   datasizewidth="48.4px" datasizeheight="42.0px" dataX="794.9" dataY="253.0"   alt="image" systemName="./images/c0a1f53b-2999-4002-8799-651bccff986d.svg" overlay="#47CF74">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 0c-6.617 0-12 5.384-12 12s5.383 12 12 12c6.616 0 12-5.384 12-12s-5.384-12-12-12zm5.341 8.866l-7.5 7c-.096.089-.219.134-.341.134-.129 0-.256-.049-.354-.146l-2.5-2.5c-.195-.195-.195-.512 0-.707s.512-.195.707 0l2.158 2.158 7.147-6.67c.201-.188.518-.179.707.023s.178.519-.024.708z" fill="#47CF74" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_39" class="pie image firer ie-background commentable hidden non-processed" customid="Resp4_KO"   datasizewidth="43.0px" datasizeheight="43.0px" dataX="839.0" dataY="462.0"   alt="image" systemName="./images/ac70b637-7443-42b9-b2ce-43ab125732e3.svg" overlay="#DD3214">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm6-10.488l-12.001-.012c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l12 .012c.276 0 .5.224.5.5-.001.276-.225.5-.5.5z" fill="#DD3214" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_40" class="pie image firer ie-background commentable hidden non-processed" customid="Resp2_KO"   datasizewidth="43.0px" datasizeheight="43.0px" dataX="732.4" dataY="326.5"   alt="image" systemName="./images/74898abc-1430-47bc-bac5-81344217b939.svg" overlay="#DD3214">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm6-10.488l-12.001-.012c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l12 .012c.276 0 .5.224.5.5-.001.276-.225.5-.5.5z" fill="#DD3214" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_41" class="pie image firer ie-background commentable hidden non-processed" customid="Resp3_KO"   datasizewidth="43.0px" datasizeheight="43.0px" dataX="751.9" dataY="396.5"   alt="image" systemName="./images/0aec097b-db50-4cfe-8040-b4e5caeb41e2.svg" overlay="#DD3214">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M11.499 0c-6.329 0-11.487 5.148-11.499 11.478-.006 3.072 1.184 5.962 3.352 8.139 2.168 2.175 5.053 3.377 8.126 3.383h.022c6.328 0 11.487-5.149 11.5-11.479.012-6.34-5.137-11.509-11.501-11.521zm.001 22.5zm6-10.488l-12.001-.012c-.276-.001-.5-.225-.499-.501 0-.275.224-.499.5-.499l12 .012c.276 0 .5.224.5.5-.001.276-.225.5-.5.5z" fill="#DD3214" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Button-black" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="183.0px" datasizeheight="51.0px" dataX="12.0" dataY="709.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_0">MEN&Uacute;</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button-black_1" class="pie richtext manualfit firer click commentable non-processed" customid="Button-black"   datasizewidth="241.2px" datasizeheight="51.0px" dataX="775.4" dataY="709.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button-black_1_0">SIGUIENTE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="500.0px" datasizeheight="500.0px" dataX="17.0" dataY="134.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/2bc4f913-e75c-437b-a1ab-c64a3d296b88.gif" />\
        	</div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;